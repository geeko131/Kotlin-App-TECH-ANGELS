
package com.example.katlegomckatbusinesslocatorapp

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object Routes {
    const val LOGIN = "login"
    const val SIGN_UP = "signup"
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CATEGORIES = "categories"
    const val BUSINESS_LIST = "businessList"
    const val BUSINESS_DETAILS = "businessDetails"
    const val MAP = "map"
    const val ADD_BUSINESS = "addBusiness"
    const val REVIEWS = "reviews"
    const val PROFILE = "profile"
}

@Composable
fun AppNavHost(
    navController: NavHostController = rememberNavController()
) {
    val context = LocalContext.current

    var loggedInUser by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedBusiness by remember { mutableStateOf<Business?>(null) }

    val businesses = remember {
        mutableStateListOf<Business>().apply {
            addAll(initialBusinesses())
        }
    }

    val reviews = remember {
        mutableStateListOf<Review>().apply {
            addAll(initialReviews())
        }
    }

    // Navigate between the main app screens without
    // repeatedly adding the same destination to the back stack.
    val navigateTo: (String) -> Unit = { route ->
        if (navController.currentDestination?.route != route) {
            navController.navigate(route) {
                launchSingleTop = true
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.LOGIN
    ) {

        // LOGIN
        composable(Routes.LOGIN) {
            LoginScreen(
                context = context,
                onSignUp = {
                    navigateTo(Routes.SIGN_UP)
                },
                onSuccess = { name ->
                    loggedInUser = name

                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }

        // SIGN UP
        composable(Routes.SIGN_UP) {
            SignUpScreen(
                context = context,
                onLogin = {
                    navigateTo(Routes.LOGIN)
                },
                onSuccess = { name ->
                    loggedInUser = name

                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SIGN_UP) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }

        // SPLASH
        composable(Routes.SPLASH) {
            SplashScreen(
                onEnter = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.SPLASH) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        // HOME
        composable(Routes.HOME) {
            HomeScreen(
                userName = loggedInUser,
                businesses = businesses,

                onBusinessClick = { business ->
                    selectedBusiness = business
                    navigateTo(Routes.BUSINESS_DETAILS)
                },

                onCategories = {
                    navigateTo(Routes.CATEGORIES)
                },

                onMap = {
                   navController.navigate(Routes.MAP){
                       launchSingleTop = true
                   }
                },

                onLogin = {
                    navigateTo(Routes.LOGIN)
                },

                onAddBusiness = {
                    navigateTo(Routes.ADD_BUSINESS)
                },

                onReviews = {
                    navigateTo(Routes.REVIEWS)
                },

                onProfile = {
                    navController.navigate(Routes.PROFILE) {
                        launchSingleTop = true
                    }
                }
            )

                    }

        // CATEGORIES
        composable(Routes.CATEGORIES) {
            CategoriesScreen(
                businesses = businesses,

                onBack = {
                    navController.popBackStack()
                },

                onCategoryClick = { category ->
                    selectedCategory = category
                    navigateTo(Routes.BUSINESS_LIST)
                }
            )
        }

        // BUSINESS LIST
        composable(Routes.BUSINESS_LIST) {
            BusinessListScreen(
                category = selectedCategory,
                businesses = businesses,

                onBack = {
                    navController.popBackStack()
                },

                onBusinessClick = { business ->
                    selectedBusiness = business
                    navigateTo(Routes.BUSINESS_DETAILS)
                }
            )
        }

        // BUSINESS DETAILS
        composable(Routes.BUSINESS_DETAILS) {
            selectedBusiness?.let { business ->
                BusinessDetailsScreen(
                    business = business,
                    reviews = reviews.filter {
                        it.businessId == business.id
                    },

                    onBack = {
                        navController.popBackStack()
                    },

                    onReviews = {
                        navigateTo(Routes.REVIEWS)
                    },

                    onContact = {
                        Toast.makeText(
                            context,
                            "Contact: ${business.phone}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }

        // MAP
        composable(Routes.MAP) {
            MapScreen(
                businesses = businesses,

                onBack = {
                    navController.popBackStack()
                },

                onBusinessClick = { business ->
                    selectedBusiness = business
                    navController.navigate(Routes.BUSINESS_DETAILS)
                },

                onHome = {
                    navigateTo(Routes.HOME)
                },

                onCategories = {
                    navigateTo(Routes.CATEGORIES)
                },

                onProfile = {
                    navigateTo(Routes.PROFILE)
                }
            )
        }

        // ADD BUSINESS
        composable(Routes.ADD_BUSINESS) {
            AddBusinessScreen(
                onBack = {
                    navController.popBackStack()
                },

                onBusinessAdded = { business ->
                    businesses.add(business)

                    Toast.makeText(
                        context,
                        "Business added successfully!",
                        Toast.LENGTH_SHORT
                    ).show()

                    navController.popBackStack()
                }
            )
        }

        // REVIEWS
        composable(Routes.REVIEWS) {
            ReviewsScreen(
                selectedBusiness = selectedBusiness
                    ?: businesses.firstOrNull(),

                businesses = businesses,
                reviews = reviews,

                onBack = {
                    navController.popBackStack()
                },

                onSelectBusiness = { business ->
                    selectedBusiness = business
                },

                onAddReview = { review ->
                    reviews.add(review)

                    Toast.makeText(
                        context,
                        "Review added successfully!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }

        // PROFILE
        composable(Routes.PROFILE) {
            ProfileScreen(
                context = context,
                userName = loggedInUser,

                onBack = {
                    navController.popBackStack()
                },

                onLogin = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.HOME) {
                            inclusive = true
                        }
                    }
                },

                onLogout = {
                    loggedInUser = ""

                    navController.navigate(Routes.LOGIN) {
                        popUpTo(navController.graph.id) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}