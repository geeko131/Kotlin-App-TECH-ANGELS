package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.katlegomckatbusinesslocatorapp.ui.theme.KatlegoMcKatBusinessLocatorAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KatlegoMcKatBusinessLocatorAppTheme {
                //Surface of app
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = White
                ) {
                    //calling function which helps with navigation
                    AppNavHost()
                }
            }
        }
    }
}

