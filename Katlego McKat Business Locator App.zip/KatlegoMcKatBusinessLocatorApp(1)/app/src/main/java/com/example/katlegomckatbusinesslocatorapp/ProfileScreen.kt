package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun ProfileScreen(
    context: Context,
    userName: String,
    onBack: () -> Unit,
    onLogin: () -> Unit,
    onLogout: () -> Unit
) {
    val preferences = context.getSharedPreferences("BusinessLocator", Context.MODE_PRIVATE)
    val email = preferences.getString("email", "")

    Column(modifier = Modifier.fillMaxSize().background(LightGrey)) {
        PageHeader(title = "Profile", onBack = onBack)
        Column(modifier = Modifier.fillMaxWidth().padding(25.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.size(95.dp).clip(CircleShape).background(LightGreen),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Green, modifier = Modifier.size(48.dp))
            }
            Spacer(modifier = Modifier.height(15.dp))

            if (userName.isEmpty()) {
                Text("Guest User", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Sign in to save favourites and write reviews.", color = GreyText, textAlign = TextAlign.Center)
                Spacer(modifier = Modifier.height(25.dp))
                Button(
                    onClick = onLogin,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("Log In")
                }
            } else {
                Text(userName, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(email ?: "", color = GreyText)
                Spacer(modifier = Modifier.height(30.dp))

                ProfileOption(title = "My Businesses", subtitle = "Manage businesses you have added")
                ProfileOption(title = "My Reviews", subtitle = "View your submitted reviews")
                ProfileOption(title = "Settings", subtitle = "Manage application settings")
                Spacer(modifier = Modifier.height(25.dp))

                OutlinedButton(
                    onClick = {
                        preferences.edit().clear().apply()
                        onLogout()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Log Out", color = Red)
                }
            }
        }
    }
}
//Second Function(
@Composable
fun ProfileOption(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = White)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = GreyText, fontSize = 13.sp)
        }
    }
}
