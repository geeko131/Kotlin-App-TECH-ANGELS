package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
//Themes for app
private val LightColors = lightColorScheme(
    primary = Green,
    onPrimary = Color.White,
    background = Color.White,
    surface = Color.White
)
//Main Function/Component for this screen
@Composable
fun BusinessLocatorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}