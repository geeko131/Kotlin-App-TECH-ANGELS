package com.example.katlegomckatbusinesslocatorapp
//Imports helps with allwoing pictures from drawable folder in all other screens
import androidx.annotation.DrawableRes

// DATA CLASSES
data class Business(
    val id: Int,
    val name: String,
    val category: String,
    val description: String,
    val address: String,
    val phone: String,
    val distance: String,
    val rating: Double,
    val reviewCount: Int,
    val services: String,
    // Optional drawable resource ID for rendering the business image across screens
    @param:DrawableRes val imageRes: Int? = null,
    // Latitude coordinate
    val latitude: Double= -25.4753, //-20000,
    // Longitude coordinate
    val longitude: Double = 30.9703
)

data class Review(
    val businessId: Int,
    val userName: String,
    val rating: Int,
    val comment: String,
    val time: String
)
// =========================================================================================
// BUSINESS PROFILES STORED HERE IN THIS FILE: DataModels.kt
// =========================================================================================
// HOW TO EDIT BUSINESS PROFILES (TEXTS, IMAGES, & COMPONENTS):
// 1. EDITING TEXT: Update 'name', 'category', 'description', 'address', 'phone', or 'services'.
// 2. EDITING IMAGES: Change 'imageRes = R.drawable.<image_name>' to point to any image file in res/drawable/.
// 3. EDITING RATINGS/REVIEWS: Change 'rating' (Double e.g. 4.5) or 'reviewCount' (Int e.g. 24).
// 4. EDITING COORDINATES: Update 'latitude' (Double) and 'longitude' (Double) for map location.
// 5. ADDING A NEW BUSINESS: Add a new Business(...) object inside the initialBusinesses() list.
// =========================================================================================

fun initialBusinesses(): List<Business> {
    return listOf(
        // Business Profile 1: The German Butcher & Grill
        Business(
            id = 1,
            name = "The German Butcher & Grill", // Edit Business Name here
            category = "Food & Dining", // Edit Category here
            description = "Authentic German sausages and steaks.", // Edit Description
            address = "25 Madiba Dr, Nelspruit", // Edit Address
            phone = "+27 (13) 123-4567", // Edit Phone Number
            distance = "1.2 km", // Edit Distance
            rating = 4.8, // Edit Rating
            reviewCount = 24, // Edit Review Count
            services = "Coffee, Breakfast, Lunch, Takeaway", // Edit Offered Services
            imageRes = R.drawable.burcher, // Edit Business Image (File stored in res/drawable/)
            latitude = -25.4712, // Latitude coordinate for The German Butcher & Grill
            longitude = 30.9754 // Longitude coordinate for The German Butcher & Grill
        ),
        // Business Profile 2: Nando's Nelspruit
        Business(
            id = 2,
            name = "Nando's Nelspruit",
            category = "Food & Dining",
            description = "Flame-grilled peri-peri chicken.",
            address = "Crossings Centre, Nelspruit",
            phone = "+27 (13) 234-5678",
            distance = "2.1 km",
            rating = 4.5,
            reviewCount = 16,
            services = "Burgers, Chips, Drinks, Takeaway",
            imageRes = R.drawable.nandos,
            latitude = -25.4801, // Latitude coordinate for Nando's Nelspruit (Crossings Centre)
            longitude = 30.9632  // Longitude coordinate for Nando's Nelspruit (Crossings Centre)
        ),
        // Business Profile 3: The Greek Kouzina
        Business(
            id = 3,
            name = "The Greek Kouzina",
            category = "Food & Dining",
            description = "Authentic Greek cuisine.",
            address = "89 Van Riebeeck St, Nelspruit",
            phone = "+27 (13) 345-6789",
            distance = "2.8 km",
            rating = 4.7,
            reviewCount = 32,
            services = "Lunch, Dinner, Takeaway",
            imageRes = R.drawable.kouzina,
            latitude = -25.4783, // Latitude coordinate for The Greek Kouzina (Van Riebeeck St)
            longitude = 30.9812  // Longitude coordinate for The Greek Kouzina (Van Riebeeck St)
        ),
        // Business Profile 4: Spur Steak Ranch
        Business(
            id = 4,
            name = "Spur Steak Ranch",
            category = "Food & Dining",
            description = "Family restaurant famous for steaks.",
            address = "Riverside, Mbombela",
            phone = "+27 (13) 456-7890",
            distance = "3.4 km",
            rating = 4.4,
            reviewCount = 20,
            services = "Beef,Steaks,Ribs, Drinks, Takeaway",
            imageRes = R.drawable.spur,
            latitude = -25.4523, // Latitude coordinate for Spur Steak Ranch (Riverside)
            longitude = 30.9791  // Longitude coordinate for Spur Steak Ranch (Riverside)
        ),
        // Business Profile 5: Ocean Basket
        Business(
            id = 5,
            name = "Ocean Basket",
            category = "Food & Dining",
            description = "Fresh seafood platters.",
            address = "Ilanga Mall, Nelspruit",
            phone = "+27 (13) 567-8901",
            distance = "1.8 km",
            rating = 4.6,
            reviewCount = 18,
            services = "Fresh seafood platters.",
            imageRes = R.drawable.blue_ocean,
            latitude = -25.4856, // Latitude coordinate for Ocean Basket (Ilanga Mall)
            longitude = 30.9524  // Longitude coordinate for Ocean Basket (Ilanga Mall)
        ),
        // Business Profile 6: Fresh Market
        Business(
            id = 6,
            name = "Riverside Mall",
            category = "Retail",
            description = "Premium shopping destination.",
            address = "Riverside Blvd, Nelspruit",
            phone = "+27 (13) 678-9012",
            distance = "2.5 km",
            rating = 4.9,
            reviewCount = 12,
            services = "Hosting a wide variety of shops,services and businesses",
            imageRes = R.drawable.mall,
            latitude = -25.4510, // Latitude coordinate for Riverside Mall
            longitude = 30.9785  // Longitude coordinate for Riverside Mall
        ),
        // Business Profile #7: Mediclinic Nelspruit
        Business(
            id = 7,
            name = "Mediclinic Nelspruit",
            category = "Health & Wellness",
            description = "Private hospital with 24/7 emergency.",
            address = "1 Madiba Dr, Nelspruit",
            phone = "+27 (13) 123-4567",
            distance = "3.0 km",
            rating = 4.6,
            reviewCount = 15,
            services = "Private hospital with 24/7 emergency.",
            imageRes = R.drawable.medic,
            latitude = -25.4725, // Latitude coordinate for Mediclinic Nelspruit (Madiba Dr)
            longitude = 30.9740  // Longitude coordinate for Mediclinic Nelspruit (Madiba Dr)
        ),
        // Business Profile #8: Clicks Pharmacy
        Business(
            id = 8,
            name = "Clicks Pharmacy",
            category = "Health & Wellness",
            description = "Full-service pharmacy.",
            address = "Crossings Centre, Nelspruit",
            phone = "+27 (13) 234-5678",
            distance = "4.0 km",
            rating = 4.7,
            reviewCount = 21,
            services = "Full-service pharmacy.",
            imageRes = R.drawable.clicks,
            latitude = -25.4803, // Latitude coordinate for Clicks Pharmacy (Crossings Centre)
            longitude = 30.9630  // Longitude coordinate for Clicks Pharmacy (Crossings Centre)
        ),
        // Business Profile #9: Bosch Car Service
        Business(
            id = 9,
            name = "Bosch Car Service",
            category = "Services & Repair",
            description = "Certified car mechanics.",
            address = "45 Industrial Rd, Nelspruit",
            phone = "+27 (13) 678-9012",
            distance = "4.2 km",
            rating = 4.8,
            reviewCount = 19,
            services = "Car repairs, servicing and diagnostics",
            imageRes = R.drawable.bosch,
            latitude = -25.4612, // Latitude coordinate for Bosch Car Service (Industrial Rd)
            longitude = 30.9915  // Longitude coordinate for Bosch Car Service (Industrial Rd)
        ),
        // Business Profile 10: Hair & Co
        Business(
            id = 10,
            name = "Hair & Co",
            category = "Beauty",
            description = "Haircuts, coloring, treatments.",
            address = "Riverside Mall, Nelspruit",
            phone = "+27 (13) 123-4567",
            distance = "4.0 km",
            rating = 4.8,
            reviewCount = 21,
            services = "Hair, Nails, Beauty Treatments",
            imageRes = R.drawable.hair,
            latitude = -25.4515, // Latitude coordinate for Hair & Co (Riverside Mall)
            longitude = 30.9788  // Longitude coordinate for Hair & Co (Riverside Mall)
        ),
        // Business Profile 11: Woolworths
        Business(
            id = 11,
            name = "Woolworths Riverside Mall",
            category = "Local Stores",
            description = "Quality food, clothing, beauty and home products.",
            address = "Madiba Dr, Riverside Mall, Mbombela, 1201",
            phone = "+27 13 757 9400",
            distance = "Nearby",
            rating = 4.3,
            reviewCount = 525,
            services = "Groceries, Food, Clothing, Beauty, Homeware",
            imageRes = R.drawable.woolworths,
            latitude = -25.4508, // Latitude coordinate for Woolworths Riverside Mall
            longitude = 30.9782  // Longitude coordinate for Woolworths Riverside Mall
        ),
        // Business Profile 12: Game
        Business(
            id = 12,
            name = "Game",
            category = "Local Stores",
            description = "Discount retailer for general merchandise, electronics, and gaming.",
            address = "Shop LG7, Ilanga Mall, Samora Machel Dr, West Acres, Mbombela, Nelspruit, 1211",
            phone = "+27 (13) 742-9000",
            distance = "3.5 km",
            rating = 4.6,
            reviewCount = 83,
            services = "Electronics, Gaming, Home Goods, Appliances",
            imageRes = R.drawable.game,
            latitude = -25.4859, // Latitude coordinate for Game (Ilanga Mall)
            longitude = 30.9520  // Longitude coordinate for Game (Ilanga Mall)
        ),
        // Business Profile 13: Cellucity
        Business(
            id = 13,
            name = "Cellucity",
            category = "Technology",
            description = "Cellular network provider and smartphone retailer.",
            address = "Shop 42, Ilanga Mall, Samora Machel Dr, West Acres, Mbombela, Nelspruit, 1211",
            phone = "+27 (13) 742-9100",
            distance = "3.5 km",
            rating = 4.5,
            reviewCount = 112,
            services = "Cellphone Contracts, Prepaid SIMs, Device Sales, Accessories",
            imageRes = R.drawable.cell_city,
            latitude = -25.4855, // Latitude coordinate for Cellucity (Ilanga Mall)
            longitude = 30.9522  // Longitude coordinate for Cellucity (Ilanga Mall)
        ),
        // Business Profile 14: PhoneFix
        Business(
            id = 14,
            name = "PhoneFix",
            category = "Technology",
            description = "Mobile phone repair services and technical diagnostics.",
            address = "Shop 12B, Riverside Mall, R40, Nelspruit, 1200",
            phone = "+27 (13) 757-2211",
            distance = "4.0 km",
            rating = 4.7,
            reviewCount = 45,
            services = "Screen Replacement, Battery Repair, Water Damage, Software Diagnostics",
            imageRes = R.drawable.phone,
            latitude = -25.4512, // Latitude coordinate for PhoneFix (Riverside Mall)
            longitude = 30.9786  // Longitude coordinate for PhoneFix (Riverside Mall)
        ),
        // Business Profile 15: Nelspruit Lodge
        Business(
            id = 15,
            name = "Nelspruit Lodge",
            category = "Travel & Accommodation",
            description = "Comfortable and affordable lodging featuring twin and family rooms with modern amenities.",
            address = "12 Samora Machel Dr, West Acres, Mbombela, Nelspruit, 1200",
            phone = "+27 (13) 741-5000",
            distance = "2.5 km",
            rating = 4.3,
            reviewCount = 156,
            services = "Twin Rooms, Family Rooms, Free Wi-Fi, Secure Parking, En-suite Bathrooms, Bar Fridge",
            imageRes = R.drawable.nelsruit_lodge,
            latitude = -25.4822, // Latitude coordinate for Nelspruit Lodge (Samora Machel Dr)
            longitude = 30.9601  // Longitude coordinate for Nelspruit Lodge (Samora Machel Dr)
        ),
        // Business Profile 16: NuMetro Riverside Mall Cinema
        Business(
            id = 16,
            name = "NuMetro Riverside Mall Cinema",
            category = "Entertainment",
            description = "Cinema chain featuring luxury VIP cinemas, multi-sensory 4DX, and large-format Xtreme screens.",
            address = "Riverside Mall, Nelspruit",
            phone = "0861 246 362",
            distance = "4.2 km",
            rating = 4.6,
            reviewCount = 1024,
            services = "Movies, VIP Cinema, 4DX, Scene Xtreme, Kidz Cinema, ScreenX",
            imageRes = R.drawable.numetro_riverside_mall_cinema,
            latitude = -25.4511, // Latitude coordinate for NuMetro Cinema (Riverside Mall)
            longitude = 30.9784  // Longitude coordinate for NuMetro Cinema (Riverside Mall)
        )
    )
}

// =========================================================================================
// INITIAL REVIEWS STORED HERE: 2 Unique Reviews for each of the 16 Business Profiles
// =========================================================================================
fun initialReviews(): List<Review> {
    return listOf(
        // Business 1: The German Butcher & Grill (2 Reviews)
        Review(businessId = 1, userName = "Thandi M.", rating = 5, comment = "Authentic German sausage and incredible steaks! Best in Nelspruit.", time = "2 days ago"),
        Review(businessId = 1, userName = "Sipho D.", rating = 4, comment = "Great atmosphere and friendly staff. Will definitely come back.", time = "1 week ago"),

        // Business 2: Nando's Nelspruit (2 Reviews)
        Review(businessId = 2, userName = "John P.", rating = 4, comment = "Delicious flame-grilled peri-peri chicken and hot chips.", time = "3 days ago"),
        Review(businessId = 2, userName = "Amanda N.", rating = 5, comment = "Fast service and fantastic meal with friends.", time = "5 days ago"),

        // Business 3: The Greek Kouzina (2 Reviews)
        Review(businessId = 3, userName = "Maria K.", rating = 5, comment = "Authentic Greek flavors, moussaka was divine!", time = "4 days ago"),
        Review(businessId = 3, userName = "David L.", rating = 4, comment = "Lovely ambiance and wonderful souvlaki.", time = "2 weeks ago"),

        // Business 4: Spur Steak Ranch (2 Reviews)
        Review(businessId = 4, userName = "Pieter V.", rating = 4, comment = "Great family restaurant, ribs and steaks are top notch.", time = "1 day ago"),
        Review(businessId = 4, userName = "Zanele M.", rating = 5, comment = "Kids love the play area and the service is always warm.", time = "6 days ago"),

        // Business 5: Ocean Basket (2 Reviews)
        Review(businessId = 5, userName = "Lerato K.", rating = 5, comment = "Fresh seafood platter was absolute perfection!", time = "3 days ago"),
        Review(businessId = 5, userName = "Chris B.", rating = 4, comment = "Wonderful calamari and friendly waitstaff at Ilanga Mall.", time = "1 week ago"),

        // Business 6: Riverside Mall (2 Reviews)
        Review(businessId = 6, userName = "Nomusa S.", rating = 5, comment = "Wonderful shopping mall with great variety of shops and parking.", time = "2 days ago"),
        Review(businessId = 6, userName = "Johan T.", rating = 4, comment = "Clean facilities and lots of top retail brands.", time = "5 days ago"),

        // Business 7: Mediclinic Nelspruit (2 Reviews)
        Review(businessId = 7, userName = "Dr. Van Der Merwe", rating = 5, comment = "Professional medical staff and exceptional 24/7 emergency care.", time = "3 days ago"),
        Review(businessId = 7, userName = "Grace N.", rating = 4, comment = "Efficient admission process and caring nurses.", time = "2 weeks ago"),

        // Business 8: Clicks Pharmacy (2 Reviews)
        Review(businessId = 8, userName = "Sarah M.", rating = 5, comment = "Very helpful pharmacists and well-stocked beauty section.", time = "1 day ago"),
        Review(businessId = 8, userName = "Michael P.", rating = 4, comment = "Quick prescription pickup at Crossings Centre.", time = "1 week ago"),

        // Business 9: Bosch Car Service (2 Reviews)
        Review(businessId = 9, userName = "Henk R.", rating = 5, comment = "Expert mechanics, fixed my car engine problem promptly.", time = "4 days ago"),
        Review(businessId = 9, userName = "Bheki S.", rating = 4, comment = "Honest pricing and thorough service report.", time = "3 weeks ago"),

        // Business 10: Hair & Co (2 Reviews)
        Review(businessId = 10, userName = "Chloe W.", rating = 5, comment = "Best haircut and color styling in Nelspruit!", time = "2 days ago"),
        Review(businessId = 10, userName = "Phindile M.", rating = 5, comment = "Friendly stylists and gorgeous salon environment.", time = "1 week ago"),

        // Business 11: Woolworths Riverside Mall (2 Reviews)
        Review(businessId = 11, userName = "Jessica T.", rating = 5, comment = "High quality food, fresh produce, and stylish clothing.", time = "1 day ago"),
        Review(businessId = 11, userName = "Robert K.", rating = 4, comment = "Loved the bakery and ready-made meal selection.", time = "4 days ago"),

        // Business 12: Game (2 Reviews)
        Review(businessId = 12, userName = "Sipho M.", rating = 4, comment = "Good electronics deals and helpful customer service.", time = "3 days ago"),
        Review(businessId = 12, userName = "Anri V.", rating = 5, comment = "Found all home appliances we needed at great prices.", time = "1 week ago"),

        // Business 13: Cellucity (2 Reviews)
        Review(businessId = 13, userName = "Tebogo M.", rating = 5, comment = "Seamless upgrade process and very knowledgeable staff.", time = "2 days ago"),
        Review(businessId = 13, userName = "Liam K.", rating = 4, comment = "Got a great deal on a new smartphone and accessories.", time = "1 week ago"),

        // Business 14: PhoneFix (2 Reviews)
        Review(businessId = 14, userName = "Dineo S.", rating = 5, comment = "Repaired my cracked phone screen in under 30 minutes!", time = "1 day ago"),
        Review(businessId = 14, userName = "Jaco B.", rating = 4, comment = "Professional service and reasonable repair rates.", time = "5 days ago"),

        // Business 15: Nelspruit Lodge (2 Reviews)
        Review(businessId = 15, userName = "Karen S.", rating = 5, comment = "Very comfortable family room and secure parking.", time = "3 days ago"),
        Review(businessId = 15, userName = "Mandla K.", rating = 4, comment = "Clean rooms, quiet atmosphere, and friendly reception.", time = "1 week ago"),

        // Business 16: NuMetro Riverside Mall Cinema (2 Reviews)
        Review(businessId = 16, userName = "Kevin R.", rating = 5, comment = "Amazing 4DX movie experience and comfortable VIP seating!", time = "1 day ago"),
        Review(businessId = 16, userName = "Natasha V.", rating = 5, comment = "Clean cinema halls and great popcorn.", time = "4 days ago")
    )
}
