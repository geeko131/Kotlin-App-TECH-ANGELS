package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun CategoriesScreen(
    businesses: List<Business>,
    onBack: () -> Unit,
    onCategoryClick: (String) -> Unit
) {
    val categories = listOf(
        Triple("Food & Dining", "Restaurants, Cafes, Takeaways", "🍴"),
        Triple("Retail", "Fashion, Electronics, More", "▣"),
        Triple("Health & Wellness", "Pharmacies, Fitness, Beauty", "♥"),
        Triple("Services & Repair", "Auto, Home, Tech Services", "⚒"),
        Triple("Local Stores", "Groceries, Essentials, More", "▤"),
        Triple("Travel & Accommodation", "Hotels, Travel, Tourism", "⌂"),
        Triple("Entertainment", "Events, Recreation, More", "★"),
        Triple("Beauty", "Hair, Nails, Beauty Services", "✦"),
        Triple("Technology", "Computers, Phones, Accessories", "▦")
    )

    Column(modifier = Modifier.fillMaxSize().background(LightGrey)) {
        PageHeader(title = "Categories", onBack = onBack)
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp)) {
            OutlinedTextField(
                value = "", onValueChange = {}, modifier = Modifier.fillMaxWidth(), enabled = false,
                placeholder = { Text("Search categories...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(modifier = Modifier.height(15.dp))
            categories.forEach { item ->
                CategoryRow(icon = item.third, title = item.first, subtitle = item.second, onClick = { onCategoryClick(item.first) })
                Spacer(modifier = Modifier.height(9.dp))
            }
        }
        BottomNavigationBar(current = "categories", onHome = onBack, onCategories = {}, onMap = {}, onProfile = {})
    }
}
//SEcond Function
@Composable
fun CategoryRow(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = White)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(LightGreen), contentAlignment = Alignment.Center) {
                Text(icon, fontSize = 21.sp, color = Green)
            }
            Spacer(modifier = Modifier.width(13.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = GreyText, fontSize = 12.sp)
            }
            Text("›", fontSize = 27.sp, color = Green)
        }
    }
}
