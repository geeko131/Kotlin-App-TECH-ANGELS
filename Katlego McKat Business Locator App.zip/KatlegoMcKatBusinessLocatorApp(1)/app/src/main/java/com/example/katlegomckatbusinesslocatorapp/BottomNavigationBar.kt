package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun PageHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(White)
            .padding(horizontal = 8.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DarkText)
        }
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = DarkText)
    }
}
//Second Function
@Composable
fun BottomNavigationBar(
    current: String,
    onHome: () -> Unit,
    onCategories: () -> Unit,
    onMap: () -> Unit,
    onProfile: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(White)
            .padding(vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        BottomNavItem(Icons.Default.Home, "Home", current == "home", onHome)
        BottomNavItem(Icons.Default.Category, "Categories", current == "categories", onCategories)
        BottomNavItem(Icons.Default.Map, "Map", current == "map", onMap)
        BottomNavItem(Icons.Default.Person, "Profile", current == "profile", onProfile)
    }
}
//Third Function
@Composable
fun BottomNavItem(icon: ImageVector, text: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = text, tint = if (selected) Green else GreyText)
        Text(text, fontSize = 10.sp, color = if (selected) Green else GreyText)
    }
}
//Fourth Function
@Composable
fun BusinessLocatorLogo(large: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        BusinessPinLogo(logoSize = if (large) 105.dp else 48.dp)
        Spacer(modifier = Modifier.width(if (large) 14.dp else 8.dp))
        Column {
            Text("Business", color = Green, fontSize = if (large) 34.sp else 17.sp, fontWeight = FontWeight.Bold)
            Text("Locator", color = DarkGreen, fontSize = if (large) 34.sp else 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}
//Fifth Function
@Composable
fun BusinessPinLogo(logoSize: androidx.compose.ui.unit.Dp) {
    Canvas(modifier = Modifier.size(logoSize)) {
        val centerX = size.width / 2f
        val mapPath = Path().apply {
            moveTo(size.width * 0.05f, size.height * 0.75f)
            lineTo(size.width * 0.30f, size.height * 0.58f)
            lineTo(size.width * 0.50f, size.height * 0.70f)
            lineTo(size.width * 0.72f, size.height * 0.55f)
            lineTo(size.width * 0.95f, size.height * 0.75f)
            lineTo(size.width * 0.75f, size.height * 0.92f)
            lineTo(size.width * 0.50f, size.height * 0.78f)
            lineTo(size.width * 0.25f, size.height * 0.92f)
            close()
        }
        drawPath(path = mapPath, color = Green)

        drawCircle(color = DarkGreen, radius = minOf(size.width, size.height) * 0.30f, center = Offset(centerX, size.height * 0.36f))
        drawCircle(color = White, radius = minOf(size.width, size.height) * 0.12f, center = Offset(centerX, size.height * 0.36f))
    }
}
//Sixth Function
@Composable
fun BottomWave(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxWidth().height(60.dp)) {
        val path = Path()
        path.moveTo(0f, size.height * 0.55f)
        path.quadraticBezierTo(size.width * 0.25f, 0f, size.width * 0.50f, size.height * 0.50f)
        path.quadraticBezierTo(size.width * 0.75f, size.height, size.width, size.height * 0.40f)
        path.lineTo(size.width, size.height)
        path.lineTo(0f, size.height)
        path.close()
        drawPath(path = path, color = Green)
    }
}
//Seventh Function
@Composable
fun BusinessListCard(business: Business, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = White)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            BusinessImagePlaceholder(business = business)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(business.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(business.category, color = GreyText, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = Green, modifier = Modifier.size(13.dp))
                    Text(business.distance, fontSize = 11.sp, color = GreyText)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("★ ${business.rating} (${business.reviewCount})", fontSize = 11.sp, color = GreyText)
                }
            }
            Text("›", fontSize = 27.sp, color = Green)
        }
    }
}
//Eighth Function
// Displays the business drawable image if available, or falls back to a initial-letter placeholder box
@Composable
fun BusinessImagePlaceholder(business: Business) {
    if (business.imageRes != null) {
        // Render business image from drawable resources
        Image(
            painter = painterResource(id = business.imageRes),
            contentDescription = business.name,
            modifier = Modifier
                .size(65.dp)
                .clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop
        )
    } else {
        // Fallback placeholder box showing first letter of business name
        Box(
            modifier = Modifier
                .size(65.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(LightGreen),
            contentAlignment = Alignment.Center
        ) {
            Text(business.name.take(1).uppercase(), fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Green)
        }
    }
}
//Ninth Function
@Composable
fun ReviewCard(review: Review) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = White),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(38.dp).clip(CircleShape).background(LightGreen),
                    contentAlignment = Alignment.Center
                ) {
                    Text(review.userName.take(1).uppercase(), color = Green, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(review.userName, fontWeight = FontWeight.Bold)
                    Text("★".repeat(review.rating), color = Yellow)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(review.comment, color = DarkText)
            Spacer(modifier = Modifier.height(5.dp))
            Text(review.time, fontSize = 11.sp, color = GreyText)
        }
    }
}
//Tenth Function(
@Composable
fun FilterChip(text: String, selected: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Green else White)
            .padding(horizontal = 15.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (selected) White else DarkText, fontSize = 12.sp)
    }
}
//Eleventh Function(
@Composable
fun InfoRow(icon: ImageVector, title: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Green)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, fontSize = 12.sp, color = GreyText)
            Text(value, fontSize = 14.sp)
        }
    }
}
//Final or 12th Function(
@Composable
fun AddField(value: String, label: String, onValueChange: (String) -> Unit, minLines: Int = 1) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        minLines = minLines,
        singleLine = minLines == 1,
        shape = RoundedCornerShape(12.dp)
    )
}
