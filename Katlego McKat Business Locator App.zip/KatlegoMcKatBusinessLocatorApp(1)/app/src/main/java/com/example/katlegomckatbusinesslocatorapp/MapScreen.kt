package com.example.katlegomckatbusinesslocatorapp

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

@Composable
fun MapScreen(
    businesses: List<Business>,
    onBack: () -> Unit,
    onBusinessClick: (Business) -> Unit,
    onHome: () -> Unit = {},
    onCategories: () -> Unit = {},
    onProfile: () -> Unit = {}
) {
    val context = LocalContext.current

    var search by remember { mutableStateOf("") }

    val mapCenter = remember {
        GeoPoint(-25.4753, 30.9698)
    }

    val filteredBusinesses = remember(search, businesses) {
        businesses.filter { business ->
            business.name.contains(search, ignoreCase = true) ||
                    business.category.contains(search, ignoreCase = true) ||
                    business.address.contains(search, ignoreCase = true)
        }
    }

    // Configure OpenStreetMap
    LaunchedEffect(context) {
        val preferences = context.getSharedPreferences(
            "osmdroid",
            Context.MODE_PRIVATE
        )

        Configuration.getInstance().load(context, preferences)
        Configuration.getInstance().userAgentValue = "BusinessLocator/1.0 (contact: YOUR_EMAIL_ADDRESS)"

    }

    // Keep a reference to the native map
    var mapView by remember { mutableStateOf<MapView?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            mapView?.onPause()
            mapView?.onDetach()
            mapView = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F8F7))
    ) {
        PageHeader(
            title = "Map",
            onBack = onBack
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(18.dp)),
                factory = { mapContext ->
                    MapView(mapContext).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        setBuiltInZoomControls(true)
                        setUseDataConnection(true)

                        controller.setZoom(13.0)
                        controller.setCenter(mapCenter)

                        mapView = this
                    }
                },
                update = { map ->
                    map.overlays.removeAll { it is Marker }

                    filteredBusinesses.forEach { business ->
                        val marker = Marker(map).apply {
                            position = GeoPoint(
                                business.latitude,
                                business.longitude
                            )

                            title = business.name

                            snippet = "${business.category}\n" +
                                    "${business.address}\n" +
                                    "Rating: ${business.rating}"

                            setAnchor(
                                Marker.ANCHOR_CENTER,
                                Marker.ANCHOR_BOTTOM
                            )

                            setOnMarkerClickListener { clickedMarker, _ ->
                                clickedMarker.showInfoWindow()
                                onBusinessClick(business)
                                true
                            }
                        }

                        map.overlays.add(marker)
                    }

                    map.invalidate()
                }
            )

            // Search field
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .zIndex(1f),
                singleLine = true,
                placeholder = {
                    Text("Search")
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search businesses"
                    )
                },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = Green,
                    unfocusedBorderColor = Color.LightGray,
                    cursorColor = Green
                )
            )

            // Return to the map's starting centre
            FloatingActionButton(
                onClick = {
                    mapView?.controller?.animateTo(mapCenter)
                    mapView?.controller?.setZoom(13.0)
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(12.dp),
                containerColor = Color.White,
                contentColor = Green
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "Return to Mbombela"
                )
            }

            if (search.isNotBlank() && filteredBusinesses.isEmpty()) {
                Card(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    )
                ) {
                    Text(
                        text = "No businesses found.",
                        modifier = Modifier.padding(20.dp),
                        color = DarkText
                    )
                }
            }

            // Required map attribution
            Text(
                text = "© OpenStreetMap contributors",
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .background(
                        Color.White.copy(alpha = 0.9f),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(4.dp),
                fontSize = 10.sp,
                color = Color.DarkGray
            )
        }

        BottomNavigationBar(
            current = "map",
            onHome = onHome,
            onCategories = onCategories,
            onMap = {},
            onProfile = onProfile
        )
    }
}
