package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun SplashScreen(onEnter: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize().background(White)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(25.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                BusinessLocatorLogo(large = true)
                Spacer(modifier = Modifier.height(25.dp))
                Text(
                    text = "Find Local Businesses Near You",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium,
                    color = DarkText,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(25.dp))
                Text(
                    text = "Discover, explore and support\nbusinesses in your area —\nquickly, easily and all in one place.",
                    fontSize = 17.sp,
                    lineHeight = 27.sp,
                    color = GreyText,
                    textAlign = TextAlign.Center
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Button(
                    onClick = onEnter,
                    modifier = Modifier.fillMaxWidth().height(58.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("Enter Business Locator", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(20.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    SplashFeature(icon = "⌖", text = "Find\nNearby")
                    SplashFeature(icon = "▦", text = "Explore\nCategories")
                    SplashFeature(icon = "★", text = "Read\nReviews")
                    SplashFeature(icon = "♡", text = "Support\nLocal")
                }
                Spacer(modifier = Modifier.height(25.dp))
            }
        }
        BottomWave(modifier = Modifier.align(Alignment.BottomCenter))
    }
}
//Second Function
@Composable
fun SplashFeature(icon: String, text: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 27.sp, color = Green, fontWeight = FontWeight.Bold)
        Text(text, fontSize = 12.sp, color = DarkText, textAlign = TextAlign.Center)
    }
}
