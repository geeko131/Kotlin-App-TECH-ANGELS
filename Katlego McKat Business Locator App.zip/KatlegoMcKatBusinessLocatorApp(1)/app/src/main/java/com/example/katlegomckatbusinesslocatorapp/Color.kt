package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.ui.graphics.Color
// COLOURS
val Green = Color(0xFF087F68)
val DarkGreen = Color(0xFF064E45)
val LightGreen = Color(0xFFE8F5F1)
val VeryLightGreen = Color(0xFFF4FAF8)
val DarkText = Color(0xFF092B2B)
val GreyText = Color(0xFF6F7D7A)
val LightGrey = Color(0xFFF5F7F6)
val BorderGrey = Color(0xFFE0E7E4)
val Red = Color(0xFFD32F2F)
val White = Color.White
val Yellow = Color(0xFFF4B400)