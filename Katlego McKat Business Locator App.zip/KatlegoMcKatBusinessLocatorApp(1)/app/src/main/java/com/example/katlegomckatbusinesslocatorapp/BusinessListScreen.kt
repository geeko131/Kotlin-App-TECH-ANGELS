package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
//Main Function/Component for this screen
@Composable
fun BusinessListScreen(
    category: String,
    businesses: List<Business>,
    onBack: () -> Unit,
    onBusinessClick: (Business) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val list = businesses.filter { business ->
        val categoryMatch = business.category == category
        val searchMatch = business.name.contains(search, ignoreCase = true)
        categoryMatch && searchMatch
    }

    Column(modifier = Modifier.fillMaxSize().background(LightGrey)) {
        PageHeader(title = category, onBack = onBack)
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth().padding(18.dp),
                singleLine = true, placeholder = { Text("Search in $category...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(14.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(text = "Nearby", selected = true)
                FilterChip(text = "Top Rated", selected = false)
                FilterChip(text = "Open Now", selected = false)
            }
            Spacer(modifier = Modifier.height(15.dp))
            list.forEach { business ->
                BusinessListCard(business = business, onClick = { onBusinessClick(business) })
                Spacer(modifier = Modifier.height(10.dp))
            }
            if (list.isEmpty()) {
                Text(
                    text = "No businesses found.",
                    color = GreyText,
                    modifier = Modifier.fillMaxWidth().padding(30.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
        BottomNavigationBar(current = "categories", onHome = onBack, onCategories = {}, onMap = {}, onProfile = {})
    }
}
