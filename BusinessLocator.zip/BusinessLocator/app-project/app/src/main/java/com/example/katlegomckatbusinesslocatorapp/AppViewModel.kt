package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

// Who is logged in (null = guest)
data class UserInfo(val uid: String, val name: String, val email: String)

// Holds the app's data and runs every Firebase call in the background.
// It survives screen rotation, so nothing reloads when the phone turns.
class AppViewModel(
    private val repository: FirebaseRepository = FirebaseRepository()
) : ViewModel() {

    // LIVE DATA FROM FIRESTORE (updates automatically when the dashboard or another phone changes it)

    // Approved businesses from the database. While the database is still empty (or can't be reached)
    // the 16 starting businesses from DataModels.kt are shown, so the app and the map never look blank.
    val businesses: StateFlow<List<Business>> = repository.approvedBusinesses()
        .map { remote -> if (remote.isEmpty()) initialBusinesses() else remote }
        .catch { error ->
            Log.e(TAG, "Loading businesses failed", error)
            emit(initialBusinesses())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initialBusinesses())

    val reviews: StateFlow<List<Review>> = repository.reviews()
        .catch { error -> Log.e(TAG, "Loading reviews failed", error); emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    // LOGIN STATE

    private val _user = MutableStateFlow(repository.currentUser?.toUserInfo())
    val user: StateFlow<UserInfo?> = _user.asStateFlow()

    // Businesses submitted by the logged-in user, including ones still waiting for approval
    @OptIn(ExperimentalCoroutinesApi::class)
    val myBusinesses: StateFlow<List<Business>> = _user
        .flatMapLatest { info ->
            if (info == null) flowOf(emptyList())
            else repository.myBusinesses(info.uid)
                .catch { error -> Log.e(TAG, "Loading my businesses failed", error); emit(emptyList()) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private var triedSeeding = false

    init {
        viewModelScope.launch {
            repository.authState().collect { firebaseUser ->
                _user.value = firebaseUser?.toUserInfo(fallbackName = _user.value?.name)
                if (firebaseUser != null) onSignedIn(firebaseUser)
            }
        }
    }

    // Runs every time a session starts (login, sign up, or the app opened while still logged in)
    private fun onSignedIn(firebaseUser: FirebaseUser) {
        viewModelScope.launch {
            try {
                repository.recordLogin(firebaseUser)
            } catch (e: Exception) {
                Log.e(TAG, "Saving last login failed", e)
            }
        }
        seedSampleData(firebaseUser.uid)
    }

    // AUTH ACTIONS

    fun signUp(name: String, email: String, password: String, onSuccess: (String) -> Unit) {
        runAuthAction {
            val firebaseUser = repository.signUp(name, email, password)
            _user.value = UserInfo(firebaseUser.uid, name, email)
            onSuccess(name)
        }
    }

    fun signIn(email: String, password: String, onSuccess: (String) -> Unit) {
        runAuthAction {
            val info = repository.signIn(email, password).toUserInfo()
            _user.value = info
            onSuccess(info.name)
        }
    }

    fun signOut() {
        repository.signOut()
        _user.value = null
        triedSeeding = false
    }

    fun clearAuthError() {
        _authError.value = null
    }

    private fun runAuthAction(action: suspend () -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            _authError.value = null
            try {
                action()
            } catch (e: Exception) {
                _authError.value = e.toFriendlyMessage()
            } finally {
                _isLoading.value = false
            }
        }
    }

    // DATA ACTIONS (the screens call these; we fill in who did it and when)

    // The business is saved as "pending" and appears in the dashboard's approval list
    fun addBusiness(business: Business, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val currentUser = _user.value ?: return onError("Please log in to add a business.")
        viewModelScope.launch {
            try {
                repository.addBusiness(
                    business.copy(
                        ownerId = currentUser.uid,
                        ownerEmail = currentUser.email,
                        createdAt = System.currentTimeMillis()
                    )
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.toFriendlyMessage())
            }
        }
    }

    fun addReview(review: Review, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val currentUser = _user.value ?: return onError("Please log in to write a review.")
        viewModelScope.launch {
            try {
                repository.addReview(
                    review.copy(
                        userId = currentUser.uid,
                        userName = currentUser.name,
                        createdAt = System.currentTimeMillis()
                    )
                )
                onSuccess()
            } catch (e: Exception) {
                onError(e.toFriendlyMessage())
            }
        }
    }

    // Only admins can write the starting data. For everybody else this simply does nothing.
    private fun seedSampleData(uid: String) {
        if (triedSeeding) return
        triedSeeding = true
        viewModelScope.launch {
            try {
                if (repository.isAdmin(uid)) {
                    repository.seedSampleDataIfEmpty(uid)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Uploading sample data failed", e)
            }
        }
    }

    private fun FirebaseUser.toUserInfo(fallbackName: String? = null) = UserInfo(
        uid = uid,
        name = displayName?.takeIf { it.isNotBlank() }
            ?: fallbackName
            ?: email.orEmpty().substringBefore("@"),
        email = email.orEmpty()
    )

    companion object {
        private const val TAG = "AppViewModel"
    }
}
