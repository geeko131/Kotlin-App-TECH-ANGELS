package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch

//
// MainScaffold: Combines Top Navigation Drawer, Top App Bar, Bottom Navigation Bar, and NavHost
// Updated for Katlego McKat Business Locator App (Removed cartCount, updated routes for Home, Categories, Map, and Profile).
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(
    navController: NavHostController = rememberNavController(),
) {
    // Controls side navigation drawer opening and closing state.
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Retrieves current destination route to highlight active navigation items in both drawer and bottom bar.
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Routes.HOME

    // Modal Navigation Drawer serving as the Top/Side Drawer menu.
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "Katlego McKat Menu",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(24.dp),
                )
                // Drawer Navigation Item: Home Screen
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = currentRoute == Routes.HOME,
                    onClick = {
                        navController.navigate(Routes.HOME) { launchSingleTop = true }
                        scope.launch { drawerState.close() }
                    },
                )
                // Drawer Navigation Item: Categories Screen
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Category, contentDescription = "Categories") },
                    label = { Text("Categories") },
                    selected = currentRoute == Routes.CATEGORIES,
                    onClick = {
                        navController.navigate(Routes.CATEGORIES) { launchSingleTop = true }
                        scope.launch { drawerState.close() }
                    },
                )
                // Drawer Navigation Item: Map Screen
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("Map") },
                    selected = currentRoute == Routes.MAP,
                    onClick = {
                        navController.navigate(Routes.MAP) { launchSingleTop = true }
                        scope.launch { drawerState.close() }
                    },
                )
                // Drawer Navigation Item: Profile Screen
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text("Profile") },
                    selected = currentRoute == Routes.PROFILE,
                    onClick = {
                        navController.navigate(Routes.PROFILE) { launchSingleTop = true }
                        scope.launch { drawerState.close() }
                    },
                )
            }
        },
    ) {
        // Core Scaffold layout containing Top App Bar, Bottom Navigation Bar, and NavHost content area.
        Scaffold(
            topBar = {
                // Top App Bar with menu icon button to open drawer and app title.
                CenterAlignedTopAppBar(
                    title = { Text("Katlego McKat Business Locator") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open Navigation Drawer")
                        }
                    }
                )
            },
            bottomBar = {
                // Bottom Navigation Bar linked to the same navigation routes as the top drawer.
                BottomNavigationBar(
                    current = when (currentRoute) {
                        Routes.CATEGORIES -> "categories"
                        Routes.MAP -> "map"
                        Routes.PROFILE -> "profile"
                        else -> "home"
                    },
                    onHome = { navController.navigate(Routes.HOME) { launchSingleTop = true } },
                    onCategories = { navController.navigate(Routes.CATEGORIES) { launchSingleTop = true } },
                    onMap = { navController.navigate(Routes.MAP) { launchSingleTop = true } },
                    onProfile = { navController.navigate(Routes.PROFILE) { launchSingleTop = true } }
                )
            },
        ) { innerPadding ->
            // NavHost managing screen transitions across Katlego McKat Business Locator routes.
            NavHost(
                navController = navController,
                startDestination = Routes.HOME,
                modifier = Modifier.padding(innerPadding),
            ) {
                composable(Routes.HOME) {
                    HomeScreen(
                        userName = "User",
                        businesses = initialBusinesses(),
                        onBusinessClick = { /* Handle business click */ },
                        onCategories = { navController.navigate(Routes.CATEGORIES) },
                        onMap = { navController.navigate(Routes.MAP) },
                        onLogin = { navController.navigate(Routes.LOGIN) },
                        onAddBusiness = { navController.navigate(Routes.ADD_BUSINESS) },
                        onReviews = { navController.navigate(Routes.REVIEWS) },
                        onProfile = { navController.navigate(Routes.PROFILE) }
                    )
                }
                composable(Routes.CATEGORIES) {
                    CategoriesScreen(
                        businesses = initialBusinesses(),
                        onBack = { navController.popBackStack() },
                        onCategoryClick = { /* Handle category selection */ }
                    )
                }
                composable(Routes.MAP) {
                    MapScreen(
                        businesses = initialBusinesses(),
                        onBack = { navController.popBackStack() },
                        onBusinessClick = { /* Handle business click */ },
                        onHome = { navController.navigate(Routes.HOME) { launchSingleTop = true } },
                        onCategories = { navController.navigate(Routes.CATEGORIES) { launchSingleTop = true } },
                        onProfile = { navController.navigate(Routes.PROFILE) { launchSingleTop = true } }
                    )
                }
                composable(Routes.PROFILE) {
                    ProfileScreen(
                        userName = "User",
                        email = "",
                        myBusinesses = emptyList(),
                        onBack = { navController.popBackStack() },
                        onLogin = { navController.navigate(Routes.LOGIN) },
                        onLogout = { navController.navigate(Routes.LOGIN) }
                    )
                }
            }
        }
    }
}
