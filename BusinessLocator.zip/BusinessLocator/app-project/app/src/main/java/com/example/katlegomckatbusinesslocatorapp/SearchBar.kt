package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

// One search bar used by the Home, Categories and Business List screens.
// The typed text is ALWAYS dark on a white background. Before, the text colour came from the phone's
// dark mode / dynamic colours, so on many phones it was white on white and looked like nothing was typed.
@Composable
fun AppSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text(placeholder, color = GreyText) },
        leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = "Search", tint = Green)
        },
        trailingIcon = {
            // Clear button appears once something is typed
            if (value.isNotEmpty()) {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear search", tint = GreyText)
                }
            }
        },
        // The keyboard shows a Search key that hides the keyboard
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = DarkText,
            unfocusedTextColor = DarkText,
            focusedContainerColor = White,
            unfocusedContainerColor = White,
            focusedBorderColor = Green,
            unfocusedBorderColor = BorderGrey,
            cursorColor = Green
        )
    )
}
