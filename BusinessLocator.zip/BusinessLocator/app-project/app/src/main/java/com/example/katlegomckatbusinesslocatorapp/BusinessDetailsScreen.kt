package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun BusinessDetailsScreen(
    business: Business,
    reviews: List<Review>,
    onBack: () -> Unit,
    onReviews: () -> Unit,
    onContact: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(LightGrey)) {
        PageHeader(title = business.name, onBack = onBack)
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp)) {
            // Displays featured business image if imageRes is present, or falls back to logo banner
            val imageRes = business.imageRes
            if (imageRes != null) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = business.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(18.dp)).background(DarkGreen),
                    contentAlignment = Alignment.Center
                ) {
                    BusinessPinLogo(logoSize = 90.dp)
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
            Text(business.name, fontSize = 27.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text(business.category, color = Green, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("★ ${business.rating} (${business.reviewCount} reviews)", color = DarkText)
            Spacer(modifier = Modifier.height(20.dp))

            InfoRow(icon = Icons.Default.LocationOn, title = "Address", value = business.address)
            InfoRow(icon = Icons.Default.Phone, title = "Phone", value = business.phone)

            Spacer(modifier = Modifier.height(18.dp))
            Text("About", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Spacer(modifier = Modifier.height(7.dp))
            Text(business.description, color = GreyText, lineHeight = 22.sp)
            Spacer(modifier = Modifier.height(18.dp))

            Text("Services", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text(business.services, color = GreyText)
            Spacer(modifier = Modifier.height(20.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onContact,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null)
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("Contact")
                }
                OutlinedButton(onClick = onReviews, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Yellow)
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("Reviews", color = Green)
                }
            }
            Spacer(modifier = Modifier.height(25.dp))

            Text("Recent Reviews", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))
            reviews.take(3).forEach { review ->
                ReviewCard(review = review)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}
