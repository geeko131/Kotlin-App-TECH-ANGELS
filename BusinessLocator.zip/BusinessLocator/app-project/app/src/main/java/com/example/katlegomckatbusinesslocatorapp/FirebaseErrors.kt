package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.FirebaseFirestoreException

// Turns Firebase errors into messages users can understand.
// Order matters: WeakPassword is a kind of InvalidCredentials, so it is checked first.
fun Throwable.toFriendlyMessage(): String = when (this) {
    is FirebaseAuthWeakPasswordException -> "Password must contain at least 6 characters."
    is FirebaseAuthUserCollisionException -> "An account with this email already exists."
    is FirebaseAuthInvalidUserException -> "No account found. Please sign up first."
    is FirebaseAuthInvalidCredentialsException -> "Incorrect email or password."
    is FirebaseNetworkException -> "No internet connection. Please try again."
    is FirebaseFirestoreException -> when (code) {
        FirebaseFirestoreException.Code.PERMISSION_DENIED -> "You don't have permission to do that. Please log in."
        FirebaseFirestoreException.Code.UNAVAILABLE -> "Server unavailable. Check your connection."
        else -> "Something went wrong. Please try again."
    }
    else -> message ?: "Something went wrong. Please try again."
}
