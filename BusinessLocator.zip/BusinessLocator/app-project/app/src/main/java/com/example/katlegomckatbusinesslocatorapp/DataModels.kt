package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.annotation.Keep
import com.google.firebase.firestore.DocumentId

// =========================================================================================
// SHARED DATA MODEL: the app, Firebase (Firestore) and the admin dashboard all use these fields.
//
// Firestore structure (same names are used by dashboard/index.html):
//   businesses/{id}  -> Business fields below      (status: pending / approved / rejected)
//   reviews/{id}     -> Review fields below        (businessId = id of a document in "businesses")
//   users/{uid}      -> name, email, createdAt, lastLoginAt   (written by the app at sign up / login)
//   admins/{uid}     -> any document here makes that account an admin (created by hand in the console)
// =========================================================================================

// A business only shows in the app once an admin has approved it in the dashboard.
const val STATUS_PENDING = "pending"
const val STATUS_APPROVED = "approved"
const val STATUS_REJECTED = "rejected"

// Default map position (Mbombela) for businesses that were added without coordinates.
const val DEFAULT_LATITUDE = -25.4753
const val DEFAULT_LONGITUDE = 30.9703

// DATA CLASSES
// Firestore needs a default value for every field so it can turn documents back into objects.
// @DocumentId fills `id` with the Firestore document ID (it is not saved as a field).
@Keep
data class Business(
    @DocumentId val id: String = "",
    val name: String = "",
    val category: String = "",
    val description: String = "",
    val address: String = "",
    val phone: String = "",
    val distance: String = "",
    val rating: Double = 0.0,
    val reviewCount: Int = 0,
    val services: String = "",
    // Name of a picture in res/drawable (for example "burcher"). Empty = show the letter placeholder.
    val imageName: String = "",
    // Map position used by MapScreen
    val latitude: Double = DEFAULT_LATITUDE,
    val longitude: Double = DEFAULT_LONGITUDE,
    val ownerId: String = "",        // uid of the user who added it
    val ownerEmail: String = "",     // shown to the admin in the dashboard
    val status: String = STATUS_PENDING,
    val createdAt: Long = System.currentTimeMillis()
)

@Keep
data class Review(
    @DocumentId val id: String = "",
    val businessId: String = "",
    val userId: String = "",
    val userName: String = "",
    val rating: Int = 0,
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

// Turns the saved time into text like "2 days ago" for the review cards
fun Review.timeAgo(): String {
    val minutes = (System.currentTimeMillis() - createdAt) / 60_000
    return when {
        minutes < 1 -> "Just now"
        minutes < 60 -> "$minutes min ago"
        minutes < 60 * 24 -> "${minutes / 60} hours ago"
        minutes < 60 * 24 * 7 -> "${minutes / (60 * 24)} days ago"
        else -> "${minutes / (60 * 24 * 7)} weeks ago"
    }
}

// The search bars use this: matches name, category, address, description and services.
fun Business.matchesSearch(query: String): Boolean {
    val text = query.trim()
    if (text.isEmpty()) return true
    return name.contains(text, ignoreCase = true) ||
            category.contains(text, ignoreCase = true) ||
            address.contains(text, ignoreCase = true) ||
            description.contains(text, ignoreCase = true) ||
            services.contains(text, ignoreCase = true)
}

// Firestore can't store a drawable ID, so it stores the picture NAME and we look the picture up here.
// To use a new picture: put it in res/drawable, add a line below, then use its name as imageName.
fun drawableForName(name: String): Int? = when (name) {
    "blue_ocean" -> R.drawable.blue_ocean
    "bosch" -> R.drawable.bosch
    "burcher" -> R.drawable.burcher
    "cell_city" -> R.drawable.cell_city
    "clicks" -> R.drawable.clicks
    "game" -> R.drawable.game
    "hair" -> R.drawable.hair
    "kouzina" -> R.drawable.kouzina
    "mall" -> R.drawable.mall
    "medic" -> R.drawable.medic
    "nandos" -> R.drawable.nandos
    "nelsruit_lodge" -> R.drawable.nelsruit_lodge
    "numetro_riverside_mall_cinema" -> R.drawable.numetro_riverside_mall_cinema
    "phone" -> R.drawable.phone
    "spur" -> R.drawable.spur
    "woolworths" -> R.drawable.woolworths
    else -> null
}

// Optional picture for a business (null when it has none)
val Business.imageRes: Int?
    get() = drawableForName(imageName)

// =========================================================================================
// BUSINESS PROFILES STORED HERE IN THIS FILE: DataModels.kt
// =========================================================================================
// These 16 businesses are the starting data. They are uploaded to Firestore once (from the admin
// dashboard "Upload sample data" button, or automatically when an admin logs in to an empty database).
// While the database is empty the app shows this list so it never looks blank.
//
// HOW TO EDIT BUSINESS PROFILES AFTER THAT: use the admin dashboard (Edit button) - the app updates live.
// =========================================================================================
fun initialBusinesses(): List<Business> {
    return listOf(
        Business(
            id = "1",
            name = "The German Butcher & Grill",
            category = "Food & Dining",
            description = "Authentic German sausages and steaks.",
            address = "25 Madiba Dr, Nelspruit",
            phone = "+27 (13) 123-4567",
            distance = "1.2 km",
            rating = 4.8,
            reviewCount = 24,
            services = "Coffee, Breakfast, Lunch, Takeaway",
            imageName = "burcher",
            latitude = -25.4712,
            longitude = 30.9754,
            status = STATUS_APPROVED
        ),
        Business(
            id = "2",
            name = "Nando's Nelspruit",
            category = "Food & Dining",
            description = "Flame-grilled peri-peri chicken.",
            address = "Crossings Centre, Nelspruit",
            phone = "+27 (13) 234-5678",
            distance = "2.1 km",
            rating = 4.5,
            reviewCount = 16,
            services = "Burgers, Chips, Drinks, Takeaway",
            imageName = "nandos",
            latitude = -25.4801,
            longitude = 30.9632,
            status = STATUS_APPROVED
        ),
        Business(
            id = "3",
            name = "The Greek Kouzina",
            category = "Food & Dining",
            description = "Authentic Greek cuisine.",
            address = "89 Van Riebeeck St, Nelspruit",
            phone = "+27 (13) 345-6789",
            distance = "2.8 km",
            rating = 4.7,
            reviewCount = 32,
            services = "Lunch, Dinner, Takeaway",
            imageName = "kouzina",
            latitude = -25.4783,
            longitude = 30.9812,
            status = STATUS_APPROVED
        ),
        Business(
            id = "4",
            name = "Spur Steak Ranch",
            category = "Food & Dining",
            description = "Family restaurant famous for steaks.",
            address = "Riverside, Mbombela",
            phone = "+27 (13) 456-7890",
            distance = "3.4 km",
            rating = 4.4,
            reviewCount = 20,
            services = "Beef,Steaks,Ribs, Drinks, Takeaway",
            imageName = "spur",
            latitude = -25.4523,
            longitude = 30.9791,
            status = STATUS_APPROVED
        ),
        Business(
            id = "5",
            name = "Ocean Basket",
            category = "Food & Dining",
            description = "Fresh seafood platters.",
            address = "Ilanga Mall, Nelspruit",
            phone = "+27 (13) 567-8901",
            distance = "1.8 km",
            rating = 4.6,
            reviewCount = 18,
            services = "Fresh seafood platters.",
            imageName = "blue_ocean",
            latitude = -25.4856,
            longitude = 30.9524,
            status = STATUS_APPROVED
        ),
        Business(
            id = "6",
            name = "Riverside Mall",
            category = "Retail",
            description = "Premium shopping destination.",
            address = "Riverside Blvd, Nelspruit",
            phone = "+27 (13) 678-9012",
            distance = "2.5 km",
            rating = 4.9,
            reviewCount = 12,
            services = "Hosting a wide variety of shops,services and businesses",
            imageName = "mall",
            latitude = -25.451,
            longitude = 30.9785,
            status = STATUS_APPROVED
        ),
        Business(
            id = "7",
            name = "Mediclinic Nelspruit",
            category = "Health & Wellness",
            description = "Private hospital with 24/7 emergency.",
            address = "1 Madiba Dr, Nelspruit",
            phone = "+27 (13) 123-4567",
            distance = "3.0 km",
            rating = 4.6,
            reviewCount = 15,
            services = "Private hospital with 24/7 emergency.",
            imageName = "medic",
            latitude = -25.4725,
            longitude = 30.974,
            status = STATUS_APPROVED
        ),
        Business(
            id = "8",
            name = "Clicks Pharmacy",
            category = "Health & Wellness",
            description = "Full-service pharmacy.",
            address = "Crossings Centre, Nelspruit",
            phone = "+27 (13) 234-5678",
            distance = "4.0 km",
            rating = 4.7,
            reviewCount = 21,
            services = "Full-service pharmacy.",
            imageName = "clicks",
            latitude = -25.4803,
            longitude = 30.963,
            status = STATUS_APPROVED
        ),
        Business(
            id = "9",
            name = "Bosch Car Service",
            category = "Services & Repair",
            description = "Certified car mechanics.",
            address = "45 Industrial Rd, Nelspruit",
            phone = "+27 (13) 678-9012",
            distance = "4.2 km",
            rating = 4.8,
            reviewCount = 19,
            services = "Car repairs, servicing and diagnostics",
            imageName = "bosch",
            latitude = -25.4612,
            longitude = 30.9915,
            status = STATUS_APPROVED
        ),
        Business(
            id = "10",
            name = "Hair & Co",
            category = "Beauty",
            description = "Haircuts, coloring, treatments.",
            address = "Riverside Mall, Nelspruit",
            phone = "+27 (13) 123-4567",
            distance = "4.0 km",
            rating = 4.8,
            reviewCount = 21,
            services = "Hair, Nails, Beauty Treatments",
            imageName = "hair",
            latitude = -25.4515,
            longitude = 30.9788,
            status = STATUS_APPROVED
        ),
        Business(
            id = "11",
            name = "Woolworths Riverside Mall",
            category = "Local Stores",
            description = "Quality food, clothing, beauty and home products.",
            address = "Madiba Dr, Riverside Mall, Mbombela, 1201",
            phone = "+27 13 757 9400",
            distance = "Nearby",
            rating = 4.3,
            reviewCount = 525,
            services = "Groceries, Food, Clothing, Beauty, Homeware",
            imageName = "woolworths",
            latitude = -25.4508,
            longitude = 30.9782,
            status = STATUS_APPROVED
        ),
        Business(
            id = "12",
            name = "Game",
            category = "Local Stores",
            description = "Discount retailer for general merchandise, electronics, and gaming.",
            address = "Shop LG7, Ilanga Mall, Samora Machel Dr, West Acres, Mbombela, Nelspruit, 1211",
            phone = "+27 (13) 742-9000",
            distance = "3.5 km",
            rating = 4.6,
            reviewCount = 83,
            services = "Electronics, Gaming, Home Goods, Appliances",
            imageName = "game",
            latitude = -25.4859,
            longitude = 30.952,
            status = STATUS_APPROVED
        ),
        Business(
            id = "13",
            name = "Cellucity",
            category = "Technology",
            description = "Cellular network provider and smartphone retailer.",
            address = "Shop 42, Ilanga Mall, Samora Machel Dr, West Acres, Mbombela, Nelspruit, 1211",
            phone = "+27 (13) 742-9100",
            distance = "3.5 km",
            rating = 4.5,
            reviewCount = 112,
            services = "Cellphone Contracts, Prepaid SIMs, Device Sales, Accessories",
            imageName = "cell_city",
            latitude = -25.4855,
            longitude = 30.9522,
            status = STATUS_APPROVED
        ),
        Business(
            id = "14",
            name = "PhoneFix",
            category = "Technology",
            description = "Mobile phone repair services and technical diagnostics.",
            address = "Shop 12B, Riverside Mall, R40, Nelspruit, 1200",
            phone = "+27 (13) 757-2211",
            distance = "4.0 km",
            rating = 4.7,
            reviewCount = 45,
            services = "Screen Replacement, Battery Repair, Water Damage, Software Diagnostics",
            imageName = "phone",
            latitude = -25.4512,
            longitude = 30.9786,
            status = STATUS_APPROVED
        ),
        Business(
            id = "15",
            name = "Nelspruit Lodge",
            category = "Travel & Accommodation",
            description = "Comfortable and affordable lodging featuring twin and family rooms with modern amenities.",
            address = "12 Samora Machel Dr, West Acres, Mbombela, Nelspruit, 1200",
            phone = "+27 (13) 741-5000",
            distance = "2.5 km",
            rating = 4.3,
            reviewCount = 156,
            services = "Twin Rooms, Family Rooms, Free Wi-Fi, Secure Parking, En-suite Bathrooms, Bar Fridge",
            imageName = "nelsruit_lodge",
            latitude = -25.4822,
            longitude = 30.9601,
            status = STATUS_APPROVED
        ),
        Business(
            id = "16",
            name = "NuMetro Riverside Mall Cinema",
            category = "Entertainment",
            description = "Cinema chain featuring luxury VIP cinemas, multi-sensory 4DX, and large-format Xtreme screens.",
            address = "Riverside Mall, Nelspruit",
            phone = "0861 246 362",
            distance = "4.2 km",
            rating = 4.6,
            reviewCount = 1024,
            services = "Movies, VIP Cinema, 4DX, Scene Xtreme, Kidz Cinema, ScreenX",
            imageName = "numetro_riverside_mall_cinema",
            latitude = -25.4511,
            longitude = 30.9784,
            status = STATUS_APPROVED
        )
    )
}

// =========================================================================================
// INITIAL REVIEWS: 2 reviews for each of the 16 business profiles (businessId = business id above)
// =========================================================================================
fun initialReviews(): List<Review> {
    val day = 24 * 60 * 60 * 1000L
    val now = System.currentTimeMillis()
    return listOf(
        Review(businessId = "1", userId = "seed", userName = "Thandi M.", rating = 5, comment = "Authentic German sausage and incredible steaks! Best in Nelspruit.", createdAt = now - 2 * day),
        Review(businessId = "1", userId = "seed", userName = "Sipho D.", rating = 4, comment = "Great atmosphere and friendly staff. Will definitely come back.", createdAt = now - 7 * day),
        Review(businessId = "2", userId = "seed", userName = "John P.", rating = 4, comment = "Delicious flame-grilled peri-peri chicken and hot chips.", createdAt = now - 3 * day),
        Review(businessId = "2", userId = "seed", userName = "Amanda N.", rating = 5, comment = "Fast service and fantastic meal with friends.", createdAt = now - 5 * day),
        Review(businessId = "3", userId = "seed", userName = "Maria K.", rating = 5, comment = "Authentic Greek flavors, moussaka was divine!", createdAt = now - 4 * day),
        Review(businessId = "3", userId = "seed", userName = "David L.", rating = 4, comment = "Lovely ambiance and wonderful souvlaki.", createdAt = now - 14 * day),
        Review(businessId = "4", userId = "seed", userName = "Pieter V.", rating = 4, comment = "Great family restaurant, ribs and steaks are top notch.", createdAt = now - 1 * day),
        Review(businessId = "4", userId = "seed", userName = "Zanele M.", rating = 5, comment = "Kids love the play area and the service is always warm.", createdAt = now - 6 * day),
        Review(businessId = "5", userId = "seed", userName = "Lerato K.", rating = 5, comment = "Fresh seafood platter was absolute perfection!", createdAt = now - 3 * day),
        Review(businessId = "5", userId = "seed", userName = "Chris B.", rating = 4, comment = "Wonderful calamari and friendly waitstaff at Ilanga Mall.", createdAt = now - 7 * day),
        Review(businessId = "6", userId = "seed", userName = "Nomusa S.", rating = 5, comment = "Wonderful shopping mall with great variety of shops and parking.", createdAt = now - 2 * day),
        Review(businessId = "6", userId = "seed", userName = "Johan T.", rating = 4, comment = "Clean facilities and lots of top retail brands.", createdAt = now - 5 * day),
        Review(businessId = "7", userId = "seed", userName = "Dr. Van Der Merwe", rating = 5, comment = "Professional medical staff and exceptional 24/7 emergency care.", createdAt = now - 3 * day),
        Review(businessId = "7", userId = "seed", userName = "Grace N.", rating = 4, comment = "Efficient admission process and caring nurses.", createdAt = now - 14 * day),
        Review(businessId = "8", userId = "seed", userName = "Sarah M.", rating = 5, comment = "Very helpful pharmacists and well-stocked beauty section.", createdAt = now - 1 * day),
        Review(businessId = "8", userId = "seed", userName = "Michael P.", rating = 4, comment = "Quick prescription pickup at Crossings Centre.", createdAt = now - 7 * day),
        Review(businessId = "9", userId = "seed", userName = "Henk R.", rating = 5, comment = "Expert mechanics, fixed my car engine problem promptly.", createdAt = now - 4 * day),
        Review(businessId = "9", userId = "seed", userName = "Bheki S.", rating = 4, comment = "Honest pricing and thorough service report.", createdAt = now - 21 * day),
        Review(businessId = "10", userId = "seed", userName = "Chloe W.", rating = 5, comment = "Best haircut and color styling in Nelspruit!", createdAt = now - 2 * day),
        Review(businessId = "10", userId = "seed", userName = "Phindile M.", rating = 5, comment = "Friendly stylists and gorgeous salon environment.", createdAt = now - 7 * day),
        Review(businessId = "11", userId = "seed", userName = "Jessica T.", rating = 5, comment = "High quality food, fresh produce, and stylish clothing.", createdAt = now - 1 * day),
        Review(businessId = "11", userId = "seed", userName = "Robert K.", rating = 4, comment = "Loved the bakery and ready-made meal selection.", createdAt = now - 4 * day),
        Review(businessId = "12", userId = "seed", userName = "Sipho M.", rating = 4, comment = "Good electronics deals and helpful customer service.", createdAt = now - 3 * day),
        Review(businessId = "12", userId = "seed", userName = "Anri V.", rating = 5, comment = "Found all home appliances we needed at great prices.", createdAt = now - 7 * day),
        Review(businessId = "13", userId = "seed", userName = "Tebogo M.", rating = 5, comment = "Seamless upgrade process and very knowledgeable staff.", createdAt = now - 2 * day),
        Review(businessId = "13", userId = "seed", userName = "Liam K.", rating = 4, comment = "Got a great deal on a new smartphone and accessories.", createdAt = now - 7 * day),
        Review(businessId = "14", userId = "seed", userName = "Dineo S.", rating = 5, comment = "Repaired my cracked phone screen in under 30 minutes!", createdAt = now - 1 * day),
        Review(businessId = "14", userId = "seed", userName = "Jaco B.", rating = 4, comment = "Professional service and reasonable repair rates.", createdAt = now - 5 * day),
        Review(businessId = "15", userId = "seed", userName = "Karen S.", rating = 5, comment = "Very comfortable family room and secure parking.", createdAt = now - 3 * day),
        Review(businessId = "15", userId = "seed", userName = "Mandla K.", rating = 4, comment = "Clean rooms, quiet atmosphere, and friendly reception.", createdAt = now - 7 * day),
        Review(businessId = "16", userId = "seed", userName = "Kevin R.", rating = 5, comment = "Amazing 4DX movie experience and comfortable VIP seating!", createdAt = now - 1 * day),
        Review(businessId = "16", userId = "seed", userName = "Natasha V.", rating = 5, comment = "Clean cinema halls and great popcorn.", createdAt = now - 4 * day)
    )
}
