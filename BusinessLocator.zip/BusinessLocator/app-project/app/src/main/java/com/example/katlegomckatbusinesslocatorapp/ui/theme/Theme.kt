package com.example.katlegomckatbusinesslocatorapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.example.katlegomckatbusinesslocatorapp.BorderGrey
import com.example.katlegomckatbusinesslocatorapp.DarkGreen
import com.example.katlegomckatbusinesslocatorapp.DarkText
import com.example.katlegomckatbusinesslocatorapp.Green
import com.example.katlegomckatbusinesslocatorapp.GreyText
import com.example.katlegomckatbusinesslocatorapp.LightGreen
import com.example.katlegomckatbusinesslocatorapp.White

// The whole app is designed on white / light-grey backgrounds, so it always uses ONE light colour scheme.
// Before, the phone's dark mode and Android 12+ "dynamic colour" changed the default text colour to white,
// which made typed text invisible in every text field on white backgrounds (search bars, Add Business, Reviews).
private val AppColorScheme = lightColorScheme(
    primary = Green,
    onPrimary = White,
    secondary = DarkGreen,
    onSecondary = White,
    background = White,
    onBackground = DarkText,
    surface = White,
    onSurface = DarkText,
    surfaceVariant = LightGreen,
    onSurfaceVariant = GreyText,
    outline = BorderGrey
)

@Composable
fun KatlegoMcKatBusinessLocatorAppTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = Typography,
        content = content
    )
}
