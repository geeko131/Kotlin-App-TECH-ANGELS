package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.snapshots
import com.google.firebase.firestore.toObjects
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.math.roundToInt

// The ONLY class that talks to Firebase. Screens and the ViewModel never use Firebase directly.
// The admin dashboard (dashboard/index.html) reads and writes the SAME collections:
//
//   users/{uid}            name, email, createdAt, lastLoginAt     -> "Accounts" tab in the dashboard
//   businesses/{id}        Business fields (status = pending/approved/rejected)
//   reviews/{id}           Review fields (businessId links it to a business)
//   admins/{uid}           empty document = this account is an admin
class FirebaseRepository {

    private val auth = Firebase.auth
    private val db = Firebase.firestore
    private val usersRef = db.collection("users")
    private val businessesRef = db.collection("businesses")
    private val reviewsRef = db.collection("reviews")
    private val adminsRef = db.collection("admins")

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    // AUTHENTICATION

    // Emits the signed-in user (or null) every time someone logs in or out
    fun authState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signUp(name: String, email: String, password: String): FirebaseUser {
        val user = auth.createUserWithEmailAndPassword(email, password).await().user
            ?: throw IllegalStateException("Sign up failed. Please try again.")
        // Save the name on the account and in a users document (the dashboard lists these accounts)
        user.updateProfile(userProfileChangeRequest { displayName = name }).await()
        val now = System.currentTimeMillis()
        usersRef.document(user.uid).set(
            mapOf("name" to name, "email" to email, "createdAt" to now, "lastLoginAt" to now)
        ).await()
        return user
    }

    suspend fun signIn(email: String, password: String): FirebaseUser {
        return auth.signInWithEmailAndPassword(email, password).await().user
            ?: throw IllegalStateException("Login failed. Please try again.")
    }

    fun signOut() {
        auth.signOut()
    }

    // Records that this account used the app (shown as "Last login" in the dashboard).
    // Only email + lastLoginAt are merged so a name saved at sign up is never overwritten.
    suspend fun recordLogin(user: FirebaseUser) {
        usersRef.document(user.uid).set(
            mapOf("email" to user.email.orEmpty(), "lastLoginAt" to System.currentTimeMillis()),
            SetOptions.merge()
        ).await()
    }

    // True when the dashboard owner has created admins/{uid} for this account
    suspend fun isAdmin(uid: String): Boolean = adminsRef.document(uid).get().await().exists()

    // BUSINESSES

    // Real-time: only APPROVED businesses are visible to everybody in the app.
    // (Sorted here instead of in the query so no Firestore index is needed.)
    fun approvedBusinesses(): Flow<List<Business>> =
        businessesRef
            .whereEqualTo("status", STATUS_APPROVED)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects<Business>().sortedBy { it.name.lowercase() }
            }

    // The businesses this user submitted (pending ones too), so they can see the approval status
    fun myBusinesses(uid: String): Flow<List<Business>> =
        businessesRef
            .whereEqualTo("ownerId", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects<Business>().sortedByDescending { it.createdAt }
            }

    // New businesses always start as "pending" until an admin approves them in the dashboard
    suspend fun addBusiness(business: Business) {
        businessesRef.add(business.copy(status = STATUS_PENDING, rating = 0.0, reviewCount = 0)).await()
    }

    // REVIEWS

    fun reviews(): Flow<List<Review>> =
        reviewsRef
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { it.toObjects<Review>() }

    // Saves the review AND updates the business's average rating in one transaction,
    // so the rating and review count can never get out of sync.
    suspend fun addReview(review: Review) {
        val businessRef = businessesRef.document(review.businessId)
        val newReviewRef = reviewsRef.document()
        db.runTransaction { transaction ->
            val business = transaction.get(businessRef)
            if (!business.exists()) {
                throw IllegalStateException("This business is not in the database yet, so it can't be reviewed.")
            }
            val oldCount = business.getLong("reviewCount") ?: 0L
            val oldRating = business.getDouble("rating") ?: 0.0
            val newCount = oldCount + 1
            val newRating = (oldRating * oldCount + review.rating) / newCount
            transaction.update(
                businessRef,
                mapOf(
                    "rating" to (newRating * 10).roundToInt() / 10.0, // one decimal, e.g. 4.3
                    "reviewCount" to newCount
                )
            )
            transaction.set(newReviewRef, review)
        }.await()
    }

    // SAMPLE DATA

    // Uploads the sample businesses and reviews from DataModels.kt once, if the database is empty.
    // Only admins are allowed to do this (see firestore.rules). The IDs are fixed, so running it
    // twice (here and from the dashboard) never creates duplicates.
    suspend fun seedSampleDataIfEmpty(uid: String) {
        val existing = businessesRef.limit(1).get().await()
        if (!existing.isEmpty) return

        val now = System.currentTimeMillis()
        val batch = db.batch()
        initialBusinesses().forEach { business ->
            batch.set(
                businessesRef.document(business.id),
                business.copy(ownerId = uid, status = STATUS_APPROVED, createdAt = now)
            )
        }
        initialReviews().forEachIndexed { index, review ->
            batch.set(reviewsRef.document("seed_review_${index + 1}"), review)
        }
        batch.commit().await()
    }
}
