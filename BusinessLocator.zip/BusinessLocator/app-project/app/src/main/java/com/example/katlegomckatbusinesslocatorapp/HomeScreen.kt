package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun HomeScreen(
    userName: String,
    businesses: List<Business>,
    onBusinessClick: (Business) -> Unit,
    onCategories: () -> Unit,
    onMap: () -> Unit,
    onLogin: () -> Unit,
    onAddBusiness: () -> Unit,
    onReviews: () -> Unit,
    onProfile: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val isSearching = search.isNotBlank()
    // Matches name, category, address, description and services (businesses comes from Firebase)
    val results = remember(search, businesses) {
        businesses.filter { it.matchesSearch(search) }
    }

    Column(modifier = Modifier.fillMaxSize().background(color = Color.LightGray)) {
        // HEADER
        Row(
            modifier = Modifier.fillMaxWidth().background(White).padding(horizontal = 18.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) {
                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = DarkText)
            }
            BusinessLocatorLogo(large = false)
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = onProfile) {
                Icon(Icons.Default.Person, contentDescription = "Profile", tint = Green)
            }
        }

        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Spacer(modifier = Modifier.height(10.dp))
            // SEARCH (typed text is always visible, see AppSearchField)
            AppSearchField(
                value = search,
                onValueChange = { search = it },
                placeholder = "Search businesses",
                modifier = Modifier.padding(horizontal = 18.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (!isSearching) {
                // SUPPORT LOCAL BANNER
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkGreen)
                ) {
                    Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Support Local\nBusinesses", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Great businesses are near you!", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                        }
                        BusinessPinLogo(logoSize = 65.dp)
                    }
                }
                Spacer(modifier = Modifier.height(15.dp))

                // QUICK CATEGORIES
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 15.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HomeCategory("🍴", "Food &\nDining", onCategories)
                    HomeCategory("▣", "Retail", onCategories)
                    HomeCategory("♥", "Health &\nWellness", onCategories)
                    HomeCategory("⚒", "Services &\nRepair", onCategories)
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // NEARBY BUSINESSES  /  SEARCH RESULTS
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isSearching) "Search results (${results.size})" else "Nearby Businesses",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkText
                )
                Spacer(modifier = Modifier.weight(1f))
                if (!isSearching) {
                    TextButton(onClick = onCategories) {
                        Text("View All", color = Green)
                    }
                }
            }
            Spacer(modifier = Modifier.height(5.dp))

            val shown = if (isSearching) results else results.take(4)
            shown.forEach { business ->
                BusinessListCard(business = business, onClick = { onBusinessClick(business) })
                Spacer(modifier = Modifier.height(9.dp))
            }
            if (isSearching && results.isEmpty()) {
                Text(
                    text = "No businesses found for \"${search.trim()}\".",
                    color = DarkText,
                    modifier = Modifier.fillMaxWidth().padding(30.dp),
                    textAlign = TextAlign.Center
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            // ACTION BUTTONS
            Button(
                onClick = onAddBusiness,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(53.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(7.dp))
                Text("Add Your Business")
            }
            Spacer(modifier = Modifier.height(15.dp))
            OutlinedButton(
                onClick = onReviews,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(53.dp)
            ) {
                Icon(Icons.Default.Star, contentDescription = null, tint = Yellow)
                Spacer(modifier = Modifier.width(7.dp))
                Text("Read Reviews", color = Green)
            }
            Spacer(modifier = Modifier.height(25.dp))
        }

        BottomNavigationBar(
            current = "home",
            onHome = {},
            onCategories = onCategories,
            onMap = onMap,
            onProfile = onProfile
        )
    }
}
//Second Function(
@Composable
fun HomeCategory(icon: String, title: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(82.dp).clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(modifier = Modifier.size(52.dp).clip(CircleShape).background(LightGreen), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 23.sp)
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(title, fontSize = 11.sp, textAlign = TextAlign.Center, color = DarkText)
    }
}
