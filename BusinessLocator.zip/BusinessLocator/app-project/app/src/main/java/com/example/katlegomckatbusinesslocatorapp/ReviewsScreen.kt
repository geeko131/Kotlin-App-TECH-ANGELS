package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip//Fixed error by adding import for Clip()
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun ReviewsScreen(
    selectedBusiness: Business?,
    businesses: List<Business>,
    reviews: List<Review>,
    onBack: () -> Unit,
    onSelectBusiness: (Business) -> Unit,
    onAddReview: (Review) -> Unit
) {
    var reviewText by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf(5) }

    Column(modifier = Modifier.fillMaxSize().background(LightGrey)) {
        PageHeader(title = "Reviews", onBack = onBack)
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text("Select Business", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(modifier = Modifier.height(10.dp))

            // Displays all business profiles horizontally so users can select any of the 16 businesses to view/add reviews
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                businesses.forEach { business ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (selectedBusiness?.id == business.id) Green else White)
                            .clickable { onSelectBusiness(business) }
                            .padding(horizontal = 13.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = business.name,
                            color = if (selectedBusiness?.id == business.id) White else DarkText,
                            fontSize = 12.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))

            if (selectedBusiness != null) {
                Text(selectedBusiness.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("★ ${selectedBusiness.rating} (${selectedBusiness.reviewCount} reviews)", color = GreyText)
                Spacer(modifier = Modifier.height(15.dp))

                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("Write a Review")
                }
                Spacer(modifier = Modifier.height(15.dp))

                Text("Your Rating", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(5.dp))

                Row {
                    (1..5).forEach { star ->
                        IconButton(onClick = { rating = star }) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "$star stars",
                                tint = if (star <= rating) Yellow else BorderGrey
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = reviewText, onValueChange = { reviewText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Write your review") },
                    minLines = 3, shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        if (reviewText.trim().isNotEmpty()) {
                            onAddReview(
                                Review(
                                    businessId = selectedBusiness.id,
                                    rating = rating,
                                    comment = reviewText.trim()
                                )
                            )
                            reviewText = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) {
                    Text("Submit Review")
                }
                Spacer(modifier = Modifier.height(25.dp))

                Text("Customer Reviews", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                // Filters and displays reviews matching the selected business ID
                reviews.filter { it.businessId == selectedBusiness.id }.forEach { review ->
                    ReviewCard(review = review)
                    Spacer(modifier = Modifier.height(9.dp))
                }
            }
        }
    }
}
