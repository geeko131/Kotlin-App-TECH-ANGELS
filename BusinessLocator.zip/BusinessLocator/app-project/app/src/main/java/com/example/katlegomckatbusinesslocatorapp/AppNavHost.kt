package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

// Every route name lives here so screens don't hard-code strings.
object Routes {
    const val LOGIN = "login"
    const val SIGN_UP = "signup"
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CATEGORIES = "categories"
    const val BUSINESS_LIST = "businessList"
    const val BUSINESS_DETAILS = "businessDetails"
    const val MAP = "map"
    const val ADD_BUSINESS = "addBusiness"
    const val REVIEWS = "reviews"
    const val PROFILE = "profile"
}

//Main Function/Component for this screen
@Composable
fun AppNavHost(
    navController: NavHostController = rememberNavController(),
    appViewModel: AppViewModel = viewModel()
) {
    val context = LocalContext.current
    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    // LIVE DATA FROM FIREBASE
    // These update by themselves when the admin approves a business in the dashboard,
    // when someone adds a review, or when data changes on another phone.
    val businesses by appViewModel.businesses.collectAsStateWithLifecycle()
    val reviews by appViewModel.reviews.collectAsStateWithLifecycle()
    val myBusinesses by appViewModel.myBusinesses.collectAsStateWithLifecycle()
    val user by appViewModel.user.collectAsStateWithLifecycle()
    val isLoading by appViewModel.isLoading.collectAsStateWithLifecycle()
    val authError by appViewModel.authError.collectAsStateWithLifecycle()
    val loggedInUser = user?.name.orEmpty()

    // Screen choices. We remember the business ID (not the object) so details
    // like the rating stay up to date after a new review.
    var selectedCategory by rememberSaveable { mutableStateOf("All") }
    var selectedBusinessId by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedBusiness = businesses.find { it.id == selectedBusinessId }

    // Someone who is still logged in from last time goes straight to Home
    val startDestination = remember {
        if (appViewModel.user.value != null) Routes.HOME else Routes.LOGIN
    }

    // Sends guests to the login screen when they try something that needs an account
    fun requireLogin(message: String, action: () -> Unit) {
        if (user == null) {
            toast(message)
            navController.navigate(Routes.LOGIN)
        } else {
            action()
        }
    }

    // Navigate between the main app screens without
    // repeatedly adding the same destination to the back stack.
    val navigateTo: (String) -> Unit = { route ->
        if (navController.currentDestination?.route != route) {
            navController.navigate(route) {
                launchSingleTop = true
            }
        }
    }

    //Links all other app screens
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {

        // LOGIN
        composable(Routes.LOGIN) {
            LoginScreen(
                isLoading = isLoading,
                authError = authError,
                onSignUp = {
                    appViewModel.clearAuthError()
                    navigateTo(Routes.SIGN_UP)
                },
                onLogin = { email, password ->
                    appViewModel.signIn(email, password) {
                        toast("Login successful!")
                        // Clear login/sign-up from the back stack and start fresh at Home
                        navController.navigate(Routes.HOME) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    }
                },
                onClearError = { appViewModel.clearAuthError() }
            )
        }

        // SIGN UP
        composable(Routes.SIGN_UP) {
            SignUpScreen(
                isLoading = isLoading,
                authError = authError,
                onLogin = {
                    appViewModel.clearAuthError()
                    navigateTo(Routes.LOGIN)
                },
                onCreateAccount = { name, email, password ->
                    appViewModel.signUp(name, email, password) {
                        toast("Account created successfully!")
                        navController.navigate(Routes.HOME) {
                            popUpTo(navController.graph.id) { inclusive = true }
                        }
                    }
                },
                onClearError = { appViewModel.clearAuthError() }
            )
        }

        // SPLASH
        composable(Routes.SPLASH) {
            SplashScreen(
                onEnter = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.SPLASH) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        // HOME
        composable(Routes.HOME) {
            HomeScreen(
                userName = loggedInUser,
                businesses = businesses,

                onBusinessClick = { business ->
                    selectedBusinessId = business.id
                    navigateTo(Routes.BUSINESS_DETAILS)
                },

                onCategories = {
                    navigateTo(Routes.CATEGORIES)
                },

                onMap = {
                    navController.navigate(Routes.MAP) {
                        launchSingleTop = true
                    }
                },

                onLogin = {
                    navigateTo(Routes.LOGIN)
                },

                onAddBusiness = {
                    requireLogin("Please log in to add a business.") {
                        navigateTo(Routes.ADD_BUSINESS)
                    }
                },

                onReviews = {
                    navigateTo(Routes.REVIEWS)
                },

                onProfile = {
                    navController.navigate(Routes.PROFILE) {
                        launchSingleTop = true
                    }
                }
            )
        }

        // CATEGORIES
        composable(Routes.CATEGORIES) {
            CategoriesScreen(
                businesses = businesses,

                onBack = {
                    navController.popBackStack()
                },

                onCategoryClick = { category ->
                    selectedCategory = category
                    navigateTo(Routes.BUSINESS_LIST)
                },

                onBusinessClick = { business ->
                    selectedBusinessId = business.id
                    navigateTo(Routes.BUSINESS_DETAILS)
                },

                onMap = {
                    navigateTo(Routes.MAP)
                },

                onProfile = {
                    navigateTo(Routes.PROFILE)
                }
            )
        }

        // BUSINESS LIST
        composable(Routes.BUSINESS_LIST) {
            BusinessListScreen(
                category = selectedCategory,
                businesses = businesses,

                onBack = {
                    navController.popBackStack()
                },

                onBusinessClick = { business ->
                    selectedBusinessId = business.id
                    navigateTo(Routes.BUSINESS_DETAILS)
                }
            )
        }

        // BUSINESS DETAILS
        composable(Routes.BUSINESS_DETAILS) {
            selectedBusiness?.let { business ->
                BusinessDetailsScreen(
                    business = business,
                    reviews = reviews.filter {
                        it.businessId == business.id
                    },

                    onBack = {
                        navController.popBackStack()
                    },

                    onReviews = {
                        navigateTo(Routes.REVIEWS)
                    },

                    onContact = {
                        toast("Contact: ${business.phone}")
                    }
                )
            }
        }

        // MAP (MapScreen.kt is unchanged - it simply receives the live list from Firebase)
        composable(Routes.MAP) {
            MapScreen(
                businesses = businesses,

                onBack = {
                    navController.popBackStack()
                },

                onBusinessClick = { business ->
                    selectedBusinessId = business.id
                    navController.navigate(Routes.BUSINESS_DETAILS)
                },

                onHome = {
                    navigateTo(Routes.HOME)
                },

                onCategories = {
                    navigateTo(Routes.CATEGORIES)
                },

                onProfile = {
                    navigateTo(Routes.PROFILE)
                }
            )
        }

        // ADD BUSINESS (saved in Firestore as "pending" until the admin approves it)
        composable(Routes.ADD_BUSINESS) {
            AddBusinessScreen(
                onBack = {
                    navController.popBackStack()
                },

                onBusinessAdded = { business ->
                    appViewModel.addBusiness(
                        business,
                        onSuccess = {
                            toast("Business submitted! It will appear once the admin approves it.")
                            navController.popBackStack()
                        },
                        onError = { message -> toast(message) }
                    )
                }
            )
        }

        // REVIEWS
        composable(Routes.REVIEWS) {
            ReviewsScreen(
                selectedBusiness = selectedBusiness
                    ?: businesses.firstOrNull(),

                businesses = businesses,
                reviews = reviews,

                onBack = {
                    navController.popBackStack()
                },

                onSelectBusiness = { business ->
                    selectedBusinessId = business.id
                },

                onAddReview = { review ->
                    requireLogin("Please log in to write a review.") {
                        appViewModel.addReview(
                            review,
                            onSuccess = { toast("Review added successfully!") },
                            onError = { message -> toast(message) }
                        )
                    }
                }
            )
        }

        // PROFILE
        composable(Routes.PROFILE) {
            ProfileScreen(
                userName = loggedInUser,
                email = user?.email.orEmpty(),
                myBusinesses = myBusinesses,

                onBack = {
                    navController.popBackStack()
                },

                onLogin = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.HOME) {
                            inclusive = true
                        }
                    }
                },

                onLogout = {
                    appViewModel.signOut()
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(navController.graph.id) {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}
