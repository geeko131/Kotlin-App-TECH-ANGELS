package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
//Main Function/Component for this screen
@Composable
fun AddBusinessScreen(
    onBack: () -> Unit,
    onBusinessAdded: (Business) -> Unit
) {
    // State variables to capture user inputs for the new business profile
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var services by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().background(LightGrey)) {
        // Page header with back navigation button
        PageHeader(title = "Add Business", onBack = onBack)
        Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text("Add Business", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = DarkText)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "New businesses are sent to the admin for approval. They appear in the app once approved.",
                color = GreyText,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(20.dp))

            // Input field for Business Name
            AddField(value = name, label = "Business Name", onValueChange = { name = it; error = "" })
            Spacer(modifier = Modifier.height(12.dp))
            // Input field for Business Category
            AddField(value = category, label = "Category", onValueChange = { category = it; error = "" })
            Spacer(modifier = Modifier.height(12.dp))
            // Input field for Business Description
            AddField(value = description, label = "Description", onValueChange = { description = it }, minLines = 3)
            Spacer(modifier = Modifier.height(12.dp))
            // Input field for Business Address
            AddField(value = address, label = "Address", onValueChange = { address = it; error = "" })
            Spacer(modifier = Modifier.height(12.dp))
            // Input field for Business Phone Number
            AddField(value = phone, label = "Phone Number", onValueChange = { phone = it })
            Spacer(modifier = Modifier.height(12.dp))
            // Input field for Services offered
            AddField(value = services, label = "Services (e.g. Coffee, Takeaway)", onValueChange = { services = it })
            Spacer(modifier = Modifier.height(15.dp))

            // Display validation error message if required fields are missing
            if (error.isNotEmpty()) {
                Text(error, color = Red)
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Submit button to validate and create the new Business object
            Button(
                onClick = {
                    if (name.isBlank() || category.isBlank() || address.isBlank()) {
                        error = "Please complete the required fields."
                    } else {
                        // The map position starts at the Mbombela default; the admin can set the exact
                        // coordinates in the dashboard when approving. The owner, status ("pending") and
                        // time are filled in by the ViewModel / FirebaseRepository.
                        val business = Business(
                            name = name.trim(),
                            category = category.trim(),
                            description = description.trim(),
                            address = address.trim(),
                            phone = phone.trim(),
                            distance = "New",
                            rating = 0.0,
                            reviewCount = 0,
                            services = services.trim().ifEmpty { "Local services" },
                            latitude = DEFAULT_LATITUDE,
                            longitude = DEFAULT_LONGITUDE
                        )
                        onBusinessAdded(business)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Submit", fontWeight = FontWeight.Bold)
            }
        }
    }
}
