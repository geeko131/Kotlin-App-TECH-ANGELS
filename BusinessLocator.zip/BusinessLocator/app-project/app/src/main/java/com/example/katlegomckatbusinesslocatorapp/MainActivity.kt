package com.example.katlegomckatbusinesslocatorapp
//IMPORTS
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.katlegomckatbusinesslocatorapp.ui.theme.KatlegoMcKatBusinessLocatorAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The app is always light, so the status bar and navigation bar icons are always dark
        // (otherwise they turn white on white when the phone is in dark mode).
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
        setContent {
            KatlegoMcKatBusinessLocatorAppTheme {
                //Surface of app
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = White
                ) {
                    //calling function which helps with navigation
                    AppNavHost()
                }
            }
        }
    }
}
