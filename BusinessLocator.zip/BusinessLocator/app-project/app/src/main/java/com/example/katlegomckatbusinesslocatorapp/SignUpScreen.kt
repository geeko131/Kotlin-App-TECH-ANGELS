
package com.example.katlegomckatbusinesslocatorapp

// IMPORTS
import android.util.Patterns
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Main Function / Component for this screen
@Composable
fun SignUpScreen(
    isLoading: Boolean,
    authError: String?,                          // error from Firebase, e.g. email already used
    onLogin: () -> Unit,
    onCreateAccount: (name: String, email: String, password: String) -> Unit,
    onClearError: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val shownError = error.ifEmpty { authError.orEmpty() }

    // Text field colors: visible black text on a white background
    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.Black,
        unfocusedTextColor = Color.Black,
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        focusedBorderColor = Green,
        unfocusedBorderColor = Color.Gray,
        focusedLabelColor = Green,
        unfocusedLabelColor = Color.DarkGray,
        cursorColor = Green,
        focusedLeadingIconColor = Green,
        unfocusedLeadingIconColor = Color.DarkGray,
        focusedTrailingIconColor = Green,
        unfocusedTrailingIconColor = Color.DarkGray
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .background(White)
            .padding(25.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(30.dp))

        BusinessLocatorLogo(large = false)

        Spacer(modifier = Modifier.height(35.dp))

        Text(
            text = "Create Your Account",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF092B2B)
        )

        Spacer(modifier = Modifier.height(7.dp))

        Text(
            text = "Join us and start exploring local businesses.",
            color = GreyText
        )

        Spacer(modifier = Modifier.height(25.dp))

        // Full name field
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                error = ""
                onClearError()
            },
            label = { Text("Full Name") },
            leadingIcon = {
                Icon(
                    Icons.Default.Person,
                    contentDescription = "Full name"
                )
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = textFieldColors
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Last name field
        OutlinedTextField(
            value = lastName,
            onValueChange = {
                lastName = it
                error = ""
                onClearError()
            },
            label = { Text("Last Name") },
            leadingIcon = {
                Icon(
                    Icons.Default.Person,
                    contentDescription = "Last name"
                )
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = textFieldColors
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Email field
        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
                error = ""
                onClearError()
            },
            label = { Text("Email Address") },
            leadingIcon = {
                Icon(
                    Icons.Default.Email,
                    contentDescription = "Email address"
                )
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = textFieldColors
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Password field with show/hide option
        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                error = ""
                onClearError()
            },
            label = { Text("Password") },
            leadingIcon = {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = "Password"
                )
            },
            trailingIcon = {
                IconButton(
                    onClick = {
                        passwordVisible = !passwordVisible
                    }
                ) {
                    Icon(
                        imageVector = if (passwordVisible) {
                            Icons.Default.VisibilityOff
                        } else {
                            Icons.Default.Visibility
                        },
                        contentDescription = if (passwordVisible) {
                            "Hide password"
                        } else {
                            "Show password"
                        }
                    )
                }
            },
            visualTransformation = if (passwordVisible) {
                VisualTransformation.None
            } else {
                PasswordVisualTransformation()
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = textFieldColors
        )

        Spacer(modifier = Modifier.height(15.dp))

        // Error message
        if (shownError.isNotEmpty()) {
            Text(
                text = shownError,
                color = Red,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))
        }

        // Sign-up button
        Button(
            onClick = {
                when {
                    name.trim().isEmpty() -> {
                        error = "Please enter your name."
                    }

                    lastName.trim().isEmpty() -> {
                        error = "Please enter your last name."
                    }

                    email.trim().isEmpty() -> {
                        error = "Please enter your email address."
                    }

                    !Patterns.EMAIL_ADDRESS
                        .matcher(email.trim())
                        .matches() -> {
                        error = "Please enter a valid email address."
                    }

                    password.length < 6 -> {
                        error = "Password must contain at least 6 characters."
                    }

                    else -> {
                        // Firebase creates the account; the full name is saved on it
                        onCreateAccount("${name.trim()} ${lastName.trim()}", email.trim(), password)
                    }
                }
            },
            enabled = !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),
            shape = RoundedCornerShape(13.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Green
            )
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Text(
                    text = "Sign Up",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Navigate to login screen
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Already have an account?",
                color = GreyText
            )

            TextButton(
                onClick = onLogin
            ) {
                Text(
                    text = "Log In",
                    color = Green,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}