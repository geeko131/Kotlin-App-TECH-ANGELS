# Business Locator – App + Firebase backend + Admin dashboard (integrated)

```
app-project/            Android Studio project (open THIS folder). MapScreen.kt is byte-for-byte unchanged.
dashboard/index.html    Admin dashboard (talks to the same Firestore as the app)
firestore.rules         Security rules (publish them!)
firebase.json, .firebaserc, firestore.indexes.json   optional: deploy rules + dashboard with Firebase CLI
```

## One-time setup (≈10 minutes)
1. **Firebase console → project `bussineocator`**
   - Authentication → Sign-in method → enable **Email/Password**.
   - Firestore Database → create it if needed → **Rules** → paste `firestore.rules` → Publish.
2. **Create your admin account**: Authentication → Users → Add user (email + password).
   Copy its **UID**, then Firestore → start collection `admins` → Document ID = that UID (any field, e.g. `role: admin`).
3. **Run the app** (Android Studio, Sync Gradle first). `applicationId` is now
   `com.example.katlegomckatbusinesslocatorapp` to match `app/google-services.json`.
4. **Open the dashboard** over http(s), not by double-click: `firebase deploy --only hosting`
   (→ https://bussineocator.web.app) or `npx serve dashboard`. Sign in with the admin account and press
   **Add / sample data → Upload sample data** (or just log in to the app with the admin account once: it uploads automatically).
   If sign-in says the API key is blocked, add a **Web app** in Project settings and paste its config into `firebaseConfig` in `index.html`.

## How the pieces share data (Firestore)
| Collection | Written by | Seen in |
|---|---|---|
| `businesses/{id}` (`status`: pending/approved/rejected) | app (new = pending), dashboard (approve/edit/add) | app Home/Categories/Map/Profile, dashboard |
| `reviews/{id}` | app (updates the business rating in a transaction), dashboard (delete) | app, dashboard Reviews tab |
| `users/{uid}` (name, email, createdAt, lastLoginAt) | app at sign-up / every login | dashboard "App accounts" tab |
| `admins/{uid}` | you, by hand | decides who is admin |

Flow: user adds a business in the app → appears in dashboard **Pending approval** → Approve → shows in the app
(and on the map) instantly. The 16 businesses from the old `DataModels.kt` are the sample data; the same fields
(name, category, description, address, phone, distance, rating, reviewCount, services, imageName, latitude, longitude)
are used everywhere. New businesses get the default Mbombela pin; set exact coordinates with **Edit** in the dashboard.

## What changed in the app
- Search bars (Home, Categories, Business list): text is now always visible (the app is forced to a light theme –
  dark mode/dynamic colour was making the text white on white), a clear (✕) button, keyboard Search key, and working
  filtering (Home shows all matches; Categories also lists matching businesses).
- Login/Sign up use Firebase Auth instead of local SharedPreferences; the session is remembered.
- Business/Review models now match Firestore (String ids, `imageName` instead of a drawable id).
- Profile shows the user's own businesses with their approval status.

## Notes
- I could not run Gradle in my environment, so the Kotlin has not been compiled here — please Sync/Build and send me any error.
- While Firestore has no approved businesses (or is unreachable) the app shows the built-in 16 businesses.
- Reviews on built-in businesses only work after the sample data is uploaded.
